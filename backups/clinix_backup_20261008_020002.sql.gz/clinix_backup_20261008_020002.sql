--
-- PostgreSQL database dump
--

\restrict Tz02pjvn2f4ObAgWIz0sh4r9kScnSyzyrZKdZTu12T5a4e2xTsLDFNv1ayP4ac6

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: atenciones_clinicas; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.atenciones_clinicas (
    id integer NOT NULL,
    paciente_id integer NOT NULL,
    unidad_medica_id integer NOT NULL,
    usuario_recepcion_id integer NOT NULL,
    fecha_hora_ingreso timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tipo_atencion character varying(20) NOT NULL,
    estado character varying(30) NOT NULL,
    area_servicio character varying(50) DEFAULT 'Medicina General'::character varying,
    CONSTRAINT atenciones_clinicas_estado_check CHECK (((estado)::text = ANY ((ARRAY['RECEPCION'::character varying, 'TRIAJE'::character varying, 'EN_CONSULTA'::character varying, 'FINALIZADA'::character varying])::text[]))),
    CONSTRAINT atenciones_clinicas_tipo_atencion_check CHECK (((tipo_atencion)::text = ANY ((ARRAY['PRIMERA_VEZ'::character varying, 'SUBSECUENTE'::character varying])::text[])))
);


ALTER TABLE public.atenciones_clinicas OWNER TO clinix_user;

--
-- Name: atenciones_clinicas_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.atenciones_clinicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.atenciones_clinicas_id_seq OWNER TO clinix_user;

--
-- Name: atenciones_clinicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.atenciones_clinicas_id_seq OWNED BY public.atenciones_clinicas.id;


--
-- Name: bitacora_productividad_diaria; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.bitacora_productividad_diaria (
    id integer NOT NULL,
    usuario_id integer NOT NULL,
    unidad_medica_id integer NOT NULL,
    fecha date NOT NULL,
    total_atenciones integer DEFAULT 0 NOT NULL,
    desglose_servicios jsonb
);


ALTER TABLE public.bitacora_productividad_diaria OWNER TO clinix_user;

--
-- Name: bitacora_productividad_diaria_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.bitacora_productividad_diaria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bitacora_productividad_diaria_id_seq OWNER TO clinix_user;

--
-- Name: bitacora_productividad_diaria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.bitacora_productividad_diaria_id_seq OWNED BY public.bitacora_productividad_diaria.id;


--
-- Name: consentimientos_informados; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consentimientos_informados (
    id integer NOT NULL,
    consulta_id integer NOT NULL,
    paciente_id integer NOT NULL,
    tutor_id integer,
    grupo_edad character varying(20) NOT NULL,
    texto_legal text NOT NULL,
    firmado boolean DEFAULT false NOT NULL,
    fecha_firma timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT consentimientos_informados_grupo_edad_check CHECK (((grupo_edad)::text = ANY ((ARRAY['INFANTIL'::character varying, 'ADOLESCENTE'::character varying, 'ADULTO'::character varying])::text[])))
);


ALTER TABLE public.consentimientos_informados OWNER TO clinix_user;

--
-- Name: consentimientos_informados_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consentimientos_informados_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consentimientos_informados_id_seq OWNER TO clinix_user;

--
-- Name: consentimientos_informados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consentimientos_informados_id_seq OWNED BY public.consentimientos_informados.id;


--
-- Name: consultas_base; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consultas_base (
    id integer NOT NULL,
    atencion_id integer NOT NULL,
    especialista_id integer NOT NULL,
    area_medica character varying(30) NOT NULL,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    motivo_consulta text NOT NULL,
    observaciones text,
    CONSTRAINT consultas_base_area_medica_check CHECK (((area_medica)::text = ANY ((ARRAY['MEDICINA_GENERAL'::character varying, 'ODONTOLOGIA'::character varying, 'NUTRICION'::character varying, 'PSICOLOGIA'::character varying])::text[])))
);


ALTER TABLE public.consultas_base OWNER TO clinix_user;

--
-- Name: consultas_base_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consultas_base_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consultas_base_id_seq OWNER TO clinix_user;

--
-- Name: consultas_base_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consultas_base_id_seq OWNED BY public.consultas_base.id;


--
-- Name: consultas_medicina_general; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consultas_medicina_general (
    id integer NOT NULL,
    consulta_id integer NOT NULL,
    nota_subjetivo text NOT NULL,
    nota_objetivo text NOT NULL,
    nota_analisis text NOT NULL,
    nota_plan text NOT NULL,
    diagnostico_cie10 character varying(10) NOT NULL,
    diagnostico_descripcion character varying(200) NOT NULL,
    clasificacion_morbilidad character varying(60) NOT NULL,
    pruebas_rapidas character varying(150),
    canalizacion_externa character varying(60),
    emite_certificado boolean DEFAULT false NOT NULL
);


ALTER TABLE public.consultas_medicina_general OWNER TO clinix_user;

--
-- Name: consultas_medicina_general_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consultas_medicina_general_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consultas_medicina_general_id_seq OWNER TO clinix_user;

--
-- Name: consultas_medicina_general_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consultas_medicina_general_id_seq OWNED BY public.consultas_medicina_general.id;


--
-- Name: consultas_nutricion; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consultas_nutricion (
    id integer NOT NULL,
    consulta_id integer NOT NULL,
    circunferencia_cintura numeric(5,1),
    circunferencia_cadera numeric(5,1),
    circunferencia_brazo numeric(4,1),
    porcentaje_grasa numeric(4,1),
    porcentaje_musculo numeric(4,1),
    consumo_agua_litros numeric(3,1),
    frecuencia_ejercicio character varying(60),
    recordatorio_24h jsonb
);


ALTER TABLE public.consultas_nutricion OWNER TO clinix_user;

--
-- Name: consultas_nutricion_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consultas_nutricion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consultas_nutricion_id_seq OWNER TO clinix_user;

--
-- Name: consultas_nutricion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consultas_nutricion_id_seq OWNED BY public.consultas_nutricion.id;


--
-- Name: consultas_odontologia; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consultas_odontologia (
    id integer NOT NULL,
    consulta_id integer NOT NULL,
    tipo_denticion character varying(20) NOT NULL,
    comorbilidades_bucales text,
    estudios_gabinete character varying(150),
    indice_cpod smallint DEFAULT 0 NOT NULL,
    indice_ceod smallint DEFAULT 0 NOT NULL,
    CONSTRAINT consultas_odontologia_tipo_denticion_check CHECK (((tipo_denticion)::text = ANY ((ARRAY['ADULTA'::character varying, 'INFANTIL'::character varying])::text[])))
);


ALTER TABLE public.consultas_odontologia OWNER TO clinix_user;

--
-- Name: consultas_odontologia_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consultas_odontologia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consultas_odontologia_id_seq OWNER TO clinix_user;

--
-- Name: consultas_odontologia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consultas_odontologia_id_seq OWNED BY public.consultas_odontologia.id;


--
-- Name: consultas_psicologia; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consultas_psicologia (
    id integer NOT NULL,
    consulta_id integer NOT NULL,
    evaluacion_clinica text NOT NULL,
    nota_evolucion text NOT NULL,
    plan_intervencion text NOT NULL
);


ALTER TABLE public.consultas_psicologia OWNER TO clinix_user;

--
-- Name: consultas_psicologia_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consultas_psicologia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consultas_psicologia_id_seq OWNER TO clinix_user;

--
-- Name: consultas_psicologia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consultas_psicologia_id_seq OWNED BY public.consultas_psicologia.id;


--
-- Name: curvas_crecimiento_oms; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.curvas_crecimiento_oms (
    id integer NOT NULL,
    consulta_nutricion_id integer NOT NULL,
    rango_edad_oms character varying(20) NOT NULL,
    zscore_peso_edad numeric(4,2),
    zscore_talla_edad numeric(4,2),
    zscore_imc_edad numeric(4,2),
    percentil_calculado smallint,
    CONSTRAINT curvas_crecimiento_oms_rango_edad_oms_check CHECK (((rango_edad_oms)::text = ANY ((ARRAY['2_A_5_ANOS'::character varying, '5_A_19_ANOS'::character varying])::text[])))
);


ALTER TABLE public.curvas_crecimiento_oms OWNER TO clinix_user;

--
-- Name: curvas_crecimiento_oms_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.curvas_crecimiento_oms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.curvas_crecimiento_oms_id_seq OWNER TO clinix_user;

--
-- Name: curvas_crecimiento_oms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.curvas_crecimiento_oms_id_seq OWNED BY public.curvas_crecimiento_oms.id;


--
-- Name: historias_clinicas; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.historias_clinicas (
    id integer NOT NULL,
    paciente_id integer NOT NULL,
    usuario_registro_id integer,
    fecha_registro timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    fecha_actualizacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ahf_diabetes boolean DEFAULT false NOT NULL,
    ahf_hipertension boolean DEFAULT false NOT NULL,
    ahf_cardiopatias boolean DEFAULT false NOT NULL,
    ahf_neoplasias boolean DEFAULT false NOT NULL,
    ahf_nefropatias boolean DEFAULT false NOT NULL,
    ahf_enfermedades_mentales boolean DEFAULT false NOT NULL,
    ahf_otros text,
    app_alergias text,
    app_quirurgicos text,
    app_transfusionales text,
    app_traumaticos text,
    app_hospitalizaciones text,
    app_cronico_degenerativas text,
    app_otros text,
    apnp_tabaquismo boolean DEFAULT false NOT NULL,
    apnp_tabaquismo_descripcion character varying(150),
    apnp_alcoholismo boolean DEFAULT false NOT NULL,
    apnp_alcoholismo_descripcion character varying(150),
    apnp_toxicomania text,
    apnp_vacunacion_completa boolean DEFAULT true NOT NULL,
    apnp_vivienda_servicios character varying(250),
    apnp_zoonosis character varying(150),
    apnp_actividad_fisica character varying(100),
    ago_menarca smallint,
    ago_ritmo_menstrual character varying(30),
    ago_fum date,
    ago_gestas smallint DEFAULT 0,
    ago_partos smallint DEFAULT 0,
    ago_cesareas smallint DEFAULT 0,
    ago_abortos smallint DEFAULT 0,
    ago_metodo_anticonceptivo character varying(100),
    ago_papanicolaou_fecha date,
    ago_mastografia_fecha date,
    ago_observaciones text,
    CONSTRAINT historias_clinicas_ago_abortos_check CHECK ((ago_abortos >= 0)),
    CONSTRAINT historias_clinicas_ago_cesareas_check CHECK ((ago_cesareas >= 0)),
    CONSTRAINT historias_clinicas_ago_gestas_check CHECK ((ago_gestas >= 0)),
    CONSTRAINT historias_clinicas_ago_menarca_check CHECK (((ago_menarca >= 8) AND (ago_menarca <= 25))),
    CONSTRAINT historias_clinicas_ago_partos_check CHECK ((ago_partos >= 0))
);


ALTER TABLE public.historias_clinicas OWNER TO clinix_user;

--
-- Name: historias_clinicas_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.historias_clinicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.historias_clinicas_id_seq OWNER TO clinix_user;

--
-- Name: historias_clinicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.historias_clinicas_id_seq OWNED BY public.historias_clinicas.id;


--
-- Name: pacientes; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.pacientes (
    id integer NOT NULL,
    unidad_medica_id integer NOT NULL,
    numero_expediente character varying(30) NOT NULL,
    fecha_registro timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    nombres character varying(80) NOT NULL,
    apellido_paterno character varying(60) NOT NULL,
    apellido_materno character varying(60),
    curp character varying(18) NOT NULL,
    fecha_nacimiento date NOT NULL,
    sexo character(1) NOT NULL,
    estado_civil character varying(25),
    escolaridad character varying(40),
    calle_numero character varying(150) NOT NULL,
    colonia character varying(100) NOT NULL,
    codigo_postal character varying(5),
    telefono character varying(15),
    derechohabiencia character varying(50) NOT NULL,
    enfermedades_previas text,
    beneficiario_programa boolean DEFAULT false NOT NULL,
    nombre_programa character varying(100),
    num_personas_vivienda smallint DEFAULT 1 NOT NULL,
    numero_afiliacion character varying(50),
    grupo_sanguineo character varying(10),
    religion character varying(50),
    ocupacion character varying(80),
    tipo_poblacion character varying(50),
    area_servicio character varying(50) DEFAULT 'Medicina General'::character varying,
    CONSTRAINT pacientes_derechohabiencia_check CHECK (((derechohabiencia)::text = ANY ((ARRAY['IMSS'::character varying, 'ISSSTE'::character varying, 'PEMEX'::character varying, 'SEDENA'::character varying, 'SEMAR'::character varying, 'IMSS-Bienestar'::character varying, 'Ninguna'::character varying])::text[]))),
    CONSTRAINT pacientes_num_personas_vivienda_check CHECK ((num_personas_vivienda >= 1)),
    CONSTRAINT pacientes_sexo_check CHECK ((sexo = ANY (ARRAY['M'::bpchar, 'F'::bpchar])))
);


ALTER TABLE public.pacientes OWNER TO clinix_user;

--
-- Name: pacientes_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.pacientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pacientes_id_seq OWNER TO clinix_user;

--
-- Name: pacientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.pacientes_id_seq OWNED BY public.pacientes.id;


--
-- Name: piezas_dentales; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.piezas_dentales (
    id integer NOT NULL,
    consulta_odontologia_id integer NOT NULL,
    numero_fdi smallint NOT NULL,
    cara_vestibular character varying(15) DEFAULT 'SANO'::character varying,
    cara_lingual character varying(15) DEFAULT 'SANO'::character varying,
    cara_mesial character varying(15) DEFAULT 'SANO'::character varying,
    cara_distal character varying(15) DEFAULT 'SANO'::character varying,
    cara_oclusal character varying(15) DEFAULT 'SANO'::character varying,
    estado_general character varying(25) DEFAULT 'NORMAL'::character varying,
    en_puente_fijo boolean DEFAULT false NOT NULL,
    tiene_protesis_corona boolean DEFAULT false NOT NULL,
    CONSTRAINT piezas_dentales_cara_distal_check CHECK (((cara_distal)::text = ANY ((ARRAY['SANO'::character varying, 'CARIES'::character varying, 'RESINA'::character varying, 'AMALGAMA'::character varying])::text[]))),
    CONSTRAINT piezas_dentales_cara_lingual_check CHECK (((cara_lingual)::text = ANY ((ARRAY['SANO'::character varying, 'CARIES'::character varying, 'RESINA'::character varying, 'AMALGAMA'::character varying])::text[]))),
    CONSTRAINT piezas_dentales_cara_mesial_check CHECK (((cara_mesial)::text = ANY ((ARRAY['SANO'::character varying, 'CARIES'::character varying, 'RESINA'::character varying, 'AMALGAMA'::character varying])::text[]))),
    CONSTRAINT piezas_dentales_cara_oclusal_check CHECK (((cara_oclusal)::text = ANY ((ARRAY['SANO'::character varying, 'CARIES'::character varying, 'RESINA'::character varying, 'AMALGAMA'::character varying])::text[]))),
    CONSTRAINT piezas_dentales_cara_vestibular_check CHECK (((cara_vestibular)::text = ANY ((ARRAY['SANO'::character varying, 'CARIES'::character varying, 'RESINA'::character varying, 'AMALGAMA'::character varying])::text[]))),
    CONSTRAINT piezas_dentales_estado_general_check CHECK (((estado_general)::text = ANY ((ARRAY['NORMAL'::character varying, 'EXTRACCION'::character varying, 'AUSENTE'::character varying])::text[])))
);


ALTER TABLE public.piezas_dentales OWNER TO clinix_user;

--
-- Name: piezas_dentales_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.piezas_dentales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.piezas_dentales_id_seq OWNER TO clinix_user;

--
-- Name: piezas_dentales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.piezas_dentales_id_seq OWNED BY public.piezas_dentales.id;


--
-- Name: procedimientos_enfermeria; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.procedimientos_enfermeria (
    id integer NOT NULL,
    triaje_id integer NOT NULL,
    tipo_procedimiento character varying(50) NOT NULL,
    cantidad smallint DEFAULT 1 NOT NULL,
    observaciones character varying(200),
    CONSTRAINT procedimientos_enfermeria_cantidad_check CHECK ((cantidad > 0))
);


ALTER TABLE public.procedimientos_enfermeria OWNER TO clinix_user;

--
-- Name: procedimientos_enfermeria_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.procedimientos_enfermeria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procedimientos_enfermeria_id_seq OWNER TO clinix_user;

--
-- Name: procedimientos_enfermeria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.procedimientos_enfermeria_id_seq OWNED BY public.procedimientos_enfermeria.id;


--
-- Name: reportes_estadisticos_mensuales; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.reportes_estadisticos_mensuales (
    id integer NOT NULL,
    unidad_medica_id integer NOT NULL,
    mes smallint NOT NULL,
    anio smallint NOT NULL,
    total_consultas integer NOT NULL,
    total_primeras_veces integer NOT NULL,
    total_subsecuentes integer NOT NULL,
    desglose_sexo jsonb NOT NULL,
    desglose_grupos_edad jsonb NOT NULL,
    desglose_morbilidad jsonb NOT NULL,
    cuadre_valido boolean DEFAULT true NOT NULL,
    fecha_generacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT reportes_estadisticos_mensuales_anio_check CHECK ((anio >= 2024)),
    CONSTRAINT reportes_estadisticos_mensuales_mes_check CHECK (((mes >= 1) AND (mes <= 12)))
);


ALTER TABLE public.reportes_estadisticos_mensuales OWNER TO clinix_user;

--
-- Name: reportes_estadisticos_mensuales_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.reportes_estadisticos_mensuales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reportes_estadisticos_mensuales_id_seq OWNER TO clinix_user;

--
-- Name: reportes_estadisticos_mensuales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.reportes_estadisticos_mensuales_id_seq OWNED BY public.reportes_estadisticos_mensuales.id;


--
-- Name: tratamientos_cruzados; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.tratamientos_cruzados (
    id integer NOT NULL,
    atencion_origen_id integer NOT NULL,
    area_origen character varying(30) NOT NULL,
    area_destino character varying(30) NOT NULL,
    prioridad character varying(15) DEFAULT 'NORMAL'::character varying NOT NULL,
    motivo_derivacion text NOT NULL,
    estado character varying(20) DEFAULT 'PENDIENTE'::character varying NOT NULL,
    fecha_hora_derivacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT tratamientos_cruzados_area_destino_check CHECK (((area_destino)::text = ANY ((ARRAY['MEDICINA_GENERAL'::character varying, 'ODONTOLOGIA'::character varying, 'NUTRICION'::character varying, 'PSICOLOGIA'::character varying])::text[]))),
    CONSTRAINT tratamientos_cruzados_estado_check CHECK (((estado)::text = ANY ((ARRAY['PENDIENTE'::character varying, 'ATENDIDO'::character varying, 'CANCELADO'::character varying])::text[]))),
    CONSTRAINT tratamientos_cruzados_prioridad_check CHECK (((prioridad)::text = ANY ((ARRAY['NORMAL'::character varying, 'URGENTE'::character varying])::text[])))
);


ALTER TABLE public.tratamientos_cruzados OWNER TO clinix_user;

--
-- Name: tratamientos_cruzados_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.tratamientos_cruzados_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tratamientos_cruzados_id_seq OWNER TO clinix_user;

--
-- Name: tratamientos_cruzados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.tratamientos_cruzados_id_seq OWNED BY public.tratamientos_cruzados.id;


--
-- Name: triaje_signos_vitales; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.triaje_signos_vitales (
    id integer NOT NULL,
    atencion_id integer NOT NULL,
    enfermero_id integer NOT NULL,
    tension_arterial character varying(15) NOT NULL,
    frecuencia_cardiaca smallint NOT NULL,
    frecuencia_respiratoria smallint NOT NULL,
    temperatura numeric(4,1) NOT NULL,
    saturacion_oxigeno smallint NOT NULL,
    glucosa_capilar smallint,
    peso_kg numeric(5,2) NOT NULL,
    talla_metros numeric(3,2) NOT NULL,
    imc numeric(4,1) NOT NULL,
    clasificacion_imc character varying(30) NOT NULL,
    detecciones_riesgo text,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT triaje_signos_vitales_frecuencia_cardiaca_check CHECK ((frecuencia_cardiaca > 0)),
    CONSTRAINT triaje_signos_vitales_frecuencia_respiratoria_check CHECK ((frecuencia_respiratoria > 0)),
    CONSTRAINT triaje_signos_vitales_glucosa_capilar_check CHECK ((glucosa_capilar > 0)),
    CONSTRAINT triaje_signos_vitales_peso_kg_check CHECK ((peso_kg > (0)::numeric)),
    CONSTRAINT triaje_signos_vitales_saturacion_oxigeno_check CHECK (((saturacion_oxigeno >= 0) AND (saturacion_oxigeno <= 100))),
    CONSTRAINT triaje_signos_vitales_talla_metros_check CHECK ((talla_metros > (0)::numeric)),
    CONSTRAINT triaje_signos_vitales_temperatura_check CHECK (((temperatura >= 30.0) AND (temperatura <= 45.0)))
);


ALTER TABLE public.triaje_signos_vitales OWNER TO clinix_user;

--
-- Name: triaje_signos_vitales_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.triaje_signos_vitales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.triaje_signos_vitales_id_seq OWNER TO clinix_user;

--
-- Name: triaje_signos_vitales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.triaje_signos_vitales_id_seq OWNED BY public.triaje_signos_vitales.id;


--
-- Name: tutores; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.tutores (
    id integer NOT NULL,
    paciente_id integer NOT NULL,
    nombre_completo character varying(150) NOT NULL,
    parentesco character varying(40) NOT NULL,
    telefono_contacto character varying(15) NOT NULL,
    tipo_identificacion character varying(50) NOT NULL,
    numero_identificacion character varying(50),
    CONSTRAINT tutores_parentesco_check CHECK (((parentesco)::text = ANY ((ARRAY['Madre'::character varying, 'Padre'::character varying, 'Tutor Legal'::character varying, 'Abuelo/a'::character varying, 'Otro'::character varying])::text[])))
);


ALTER TABLE public.tutores OWNER TO clinix_user;

--
-- Name: tutores_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.tutores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tutores_id_seq OWNER TO clinix_user;

--
-- Name: tutores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.tutores_id_seq OWNED BY public.tutores.id;


--
-- Name: unidades_medicas; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.unidades_medicas (
    id integer NOT NULL,
    nombre character varying(120) NOT NULL,
    clave_oficial character varying(20) NOT NULL,
    direccion character varying(250) NOT NULL,
    colonia character varying(100) NOT NULL,
    telefono character varying(15),
    georreferencia character varying(50),
    activo boolean DEFAULT true NOT NULL
);


ALTER TABLE public.unidades_medicas OWNER TO clinix_user;

--
-- Name: unidades_medicas_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.unidades_medicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.unidades_medicas_id_seq OWNER TO clinix_user;

--
-- Name: unidades_medicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.unidades_medicas_id_seq OWNED BY public.unidades_medicas.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    unidad_medica_id integer NOT NULL,
    nombre character varying(80) NOT NULL,
    apellidos character varying(100) NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(255) NOT NULL,
    rol character varying(30) NOT NULL,
    cedula_profesional character varying(25),
    activo boolean DEFAULT true NOT NULL,
    ultimo_acceso timestamp without time zone,
    CONSTRAINT usuarios_rol_check CHECK (((rol)::text = ANY ((ARRAY['RECEPCION'::character varying, 'ENFERMERIA'::character varying, 'MEDICO_GENERAL'::character varying, 'ODONTOLOGO'::character varying, 'NUTRIOLOGO'::character varying, 'PSICOLOGO'::character varying, 'DIRECCION'::character varying])::text[])))
);


ALTER TABLE public.usuarios OWNER TO clinix_user;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_seq OWNER TO clinix_user;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: atenciones_clinicas id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.atenciones_clinicas ALTER COLUMN id SET DEFAULT nextval('public.atenciones_clinicas_id_seq'::regclass);


--
-- Name: bitacora_productividad_diaria id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.bitacora_productividad_diaria ALTER COLUMN id SET DEFAULT nextval('public.bitacora_productividad_diaria_id_seq'::regclass);


--
-- Name: consentimientos_informados id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consentimientos_informados ALTER COLUMN id SET DEFAULT nextval('public.consentimientos_informados_id_seq'::regclass);


--
-- Name: consultas_base id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_base ALTER COLUMN id SET DEFAULT nextval('public.consultas_base_id_seq'::regclass);


--
-- Name: consultas_medicina_general id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_medicina_general ALTER COLUMN id SET DEFAULT nextval('public.consultas_medicina_general_id_seq'::regclass);


--
-- Name: consultas_nutricion id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_nutricion ALTER COLUMN id SET DEFAULT nextval('public.consultas_nutricion_id_seq'::regclass);


--
-- Name: consultas_odontologia id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_odontologia ALTER COLUMN id SET DEFAULT nextval('public.consultas_odontologia_id_seq'::regclass);


--
-- Name: consultas_psicologia id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_psicologia ALTER COLUMN id SET DEFAULT nextval('public.consultas_psicologia_id_seq'::regclass);


--
-- Name: curvas_crecimiento_oms id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.curvas_crecimiento_oms ALTER COLUMN id SET DEFAULT nextval('public.curvas_crecimiento_oms_id_seq'::regclass);


--
-- Name: historias_clinicas id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.historias_clinicas ALTER COLUMN id SET DEFAULT nextval('public.historias_clinicas_id_seq'::regclass);


--
-- Name: pacientes id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.pacientes ALTER COLUMN id SET DEFAULT nextval('public.pacientes_id_seq'::regclass);


--
-- Name: piezas_dentales id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.piezas_dentales ALTER COLUMN id SET DEFAULT nextval('public.piezas_dentales_id_seq'::regclass);


--
-- Name: procedimientos_enfermeria id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.procedimientos_enfermeria ALTER COLUMN id SET DEFAULT nextval('public.procedimientos_enfermeria_id_seq'::regclass);


--
-- Name: reportes_estadisticos_mensuales id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.reportes_estadisticos_mensuales ALTER COLUMN id SET DEFAULT nextval('public.reportes_estadisticos_mensuales_id_seq'::regclass);


--
-- Name: tratamientos_cruzados id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tratamientos_cruzados ALTER COLUMN id SET DEFAULT nextval('public.tratamientos_cruzados_id_seq'::regclass);


--
-- Name: triaje_signos_vitales id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.triaje_signos_vitales ALTER COLUMN id SET DEFAULT nextval('public.triaje_signos_vitales_id_seq'::regclass);


--
-- Name: tutores id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tutores ALTER COLUMN id SET DEFAULT nextval('public.tutores_id_seq'::regclass);


--
-- Name: unidades_medicas id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.unidades_medicas ALTER COLUMN id SET DEFAULT nextval('public.unidades_medicas_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: atenciones_clinicas; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.atenciones_clinicas (id, paciente_id, unidad_medica_id, usuario_recepcion_id, fecha_hora_ingreso, tipo_atencion, estado, area_servicio) FROM stdin;
1	3	1	3	2026-09-25 18:31:58.913502	PRIMERA_VEZ	FINALIZADA	Medicina General
2	1	1	1	2026-09-25 20:32:40.051457	PRIMERA_VEZ	EN_CONSULTA	Medicina General
3	1	1	1	2026-09-25 20:36:57.176797	SUBSECUENTE	EN_CONSULTA	Medicina General
4	1	1	1	2026-09-25 20:41:21.596225	PRIMERA_VEZ	FINALIZADA	Medicina General
5	1	1	1	2026-09-25 20:49:31.708468	SUBSECUENTE	EN_CONSULTA	Medicina General
6	1	1	1	2026-09-25 20:57:16.521021	PRIMERA_VEZ	FINALIZADA	Medicina General
7	1	1	1	2026-09-25 21:00:37.349602	SUBSECUENTE	EN_CONSULTA	Medicina General
9	7	1	9	2026-09-28 19:33:31.812443	PRIMERA_VEZ	TRIAJE	Medicina General
10	5	1	9	2026-09-28 19:33:31.831355	SUBSECUENTE	EN_CONSULTA	Medicina General
11	6	1	9	2026-09-28 19:33:31.856845	PRIMERA_VEZ	EN_CONSULTA	Medicina General
13	10	1	9	2026-10-02 23:17:07.87253	PRIMERA_VEZ	TRIAJE	Medicina General
12	9	1	9	2026-10-02 23:16:41.645728	PRIMERA_VEZ	FINALIZADA	Medicina General
14	12	1	9	2026-10-05 17:58:49.147656	PRIMERA_VEZ	EN_CONSULTA	Nutrición
8	4	1	1	2026-09-25 21:57:12.579959	PRIMERA_VEZ	EN_CONSULTA	Medicina General
15	21	1	9	2026-10-05 20:03:58.151198	PRIMERA_VEZ	EN_CONSULTA	Medicina General
16	23	1	9	2026-10-06 22:19:27.706833	PRIMERA_VEZ	EN_CONSULTA	Medicina General
17	24	1	9	2026-10-07 18:40:01.919248	PRIMERA_VEZ	EN_CONSULTA	Medicina General
\.


--
-- Data for Name: bitacora_productividad_diaria; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.bitacora_productividad_diaria (id, usuario_id, unidad_medica_id, fecha, total_atenciones, desglose_servicios) FROM stdin;
1	2	1	2026-09-25	1	\N
2	5	1	2026-09-25	1	\N
3	6	1	2026-09-25	1	\N
4	1	1	2026-09-25	7	{"femenino": 0, "masculino": 7, "primera_vez": 4, "subsecuente": 3}
\.


--
-- Data for Name: consentimientos_informados; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consentimientos_informados (id, consulta_id, paciente_id, tutor_id, grupo_edad, texto_legal, firmado, fecha_firma) FROM stdin;
1	2	3	1	INFANTIL	Manifiesto que he sido informada del plan nutricional y acepto las pautas dietéticas conforme a la NOM-004-SSA3-2012.	t	2026-09-25 19:07:52.339905
2	3	3	1	INFANTIL	Autorizo la intervención psicoterapéutica para el menor bajo los términos de confidencialidad de la NOM-004-SSA3-2012 y LGPDPPSO.	t	2026-09-25 19:15:10.763836
3	7	1	\N	ADULTO	Por medio del presente documento, en mi calidad de madre, padre o tutor legal del paciente menor de edad, otorgo mi consentimiento libre, informado y expreso para la valoración, evaluación diagnóstica e intervención psicológica del menor en la Dirección de Salud Pública Municipal de Coatzacoalcos, Veracruz, garantizando la confidencialidad de la información salvo riesgo inminente a su integridad física o emocional.	t	2026-09-25 20:57:16.735802
\.


--
-- Data for Name: consultas_base; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consultas_base (id, atencion_id, especialista_id, area_medica, fecha_hora, motivo_consulta, observaciones) FROM stdin;
1	1	2	MEDICINA_GENERAL	2026-09-25 19:01:06.227023	Fiebre leve y dolor faríngeo de 48 horas de evolución	Paciente cooperador acompañado de su madre.
2	1	5	NUTRICION	2026-09-25 19:07:52.339905	Valoración nutricional preventiva por bajo peso	Paciente cooperador, tutora interesada en plan de incremento calórico.
3	1	6	PSICOLOGIA	2026-09-25 19:15:10.763836	Valoración inicial por estrés y ansiedad vinculada al entorno escolar	Menor asiste acompañado de su madre. Disposición favorable.
4	2	1	ODONTOLOGIA	2026-09-25 20:32:40.570416	Valoración odontológica y limpieza general	Se observa lesión cariosa en pieza 18 y pérdida de pieza 24.
5	3	1	NUTRICION	2026-09-25 20:36:57.340329	Control de peso y plan de alimentación personalizado	Paciente con buenos hábitos de hidratación, requiere ajuste en consumo de carbohidratos.
6	4	1	MEDICINA_GENERAL	2026-09-25 20:41:21.9154	Cefalea persistente y malestar general	Paciente acude sin acompañante.
7	6	1	PSICOLOGIA	2026-09-25 20:57:16.735802	Sintomatología ansiosa y dificultades en manejo de estrés laboral	Paciente colaborativo, con adecuada introspección y orientación temporoespacial.
8	12	11	MEDICINA_GENERAL	2026-10-02 23:24:34.393719	Dolor de garganta, febrícula y malestar general desde hace 2 días.	Faringe hiperémica con placas blanquecinas en amígdalas.
\.


--
-- Data for Name: consultas_medicina_general; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consultas_medicina_general (id, consulta_id, nota_subjetivo, nota_objetivo, nota_analisis, nota_plan, diagnostico_cie10, diagnostico_descripcion, clasificacion_morbilidad, pruebas_rapidas, canalizacion_externa, emite_certificado) FROM stdin;
1	1	Madre refiere que el menor inició hace 2 días con odinofagia, rinorrea hialina y febrícula no cuantificada.	Faringe hiperémica con amígdalas grado II sin placas blanquecinas ni exudado. Campos pulmonares limpios. Somatometría de triaje con IMC 16.5.	Cuadro clínico compatible con infección respiratoria alta aguda de presunta etiología viral.	Paracetamol suspensión 15 mg/kg cada 8 horas por 3 días si hay dolor o fiebre. Abundantes líquidos orales. Datos de alarma explicados a la madre.	J00	Rinofaringitis aguda (resfriado común)	Infecciones Respiratorias Agudas	\N	\N	f
2	6	Refiere dolor de cabeza holocraneal de 3 días de evolución, intensidad 6/10, acompañado de astenia.	Paciente consciente, orientado. Faringe hiperémica sin exudado. T/A: 120/80 mmHg, FC: 76 lpm, Temp: 36.8°C.	Cuadro clínico compatible con cefalea tensional secundaria a estrés laboral. Se descarta proceso infeccioso activo agudo.	Paracetamol 500mg cada 8 horas por 3 días si hay dolor. Abundante hidratación y medidas higiénico-dietéticas. Cita abierta.	J00	Rinofaringitis aguda [resfriado común]	Infecciones respiratorias agudas	Glucosa capilar: 92 mg/dL (Normal)	\N	f
3	8	Paciente refiere odinofagia intensa de 48 horas de evolución.	Faringe congestiva, exudado purulento amigdalino, ganglios submandibulares palpables.	Cuadro clínico compatible con Faringoamigdalitis bacteriana aguda.	Amoxicilina con Ácido Clavulánico 875/125 mg c/12h por 7 días, Paracetamol 500 mg c/8h por 3 días.	J02.9	Faringitis aguda, no especificada	Infecciones respiratorias agudas	Prueba rápida de estreptococo (+)	Ninguna	f
\.


--
-- Data for Name: consultas_nutricion; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consultas_nutricion (id, consulta_id, circunferencia_cintura, circunferencia_cadera, circunferencia_brazo, porcentaje_grasa, porcentaje_musculo, consumo_agua_litros, frecuencia_ejercicio, recordatorio_24h) FROM stdin;
1	2	54.0	58.0	15.5	14.2	38.5	1.2	3 días / semana actividad física escolar	{"cena": "Quesadilla con agua de frutas", "comida": "Sopa de verduras con pechuga de pollo y tortilla", "desayuno": "Leche entera con avena y un plátano", "colacion_matutina": "Manzana picada", "colacion_vespertina": "Galletas de trigo"}
2	5	88.0	100.0	32.5	22.4	38.1	2.5	3 veces por semana (gimnasio)	{"cena": "Quesadillas de maíz con queso panela", "comida": "Pechuga a la plancha con arroz y ensalada verde", "desayuno": "Huevos con verduras, 2 tortillas y café sin azúcar", "colacion_matutina": "1 manzana y un puñado de almendras", "colacion_vespertina": "Yogurt griego natural"}
\.


--
-- Data for Name: consultas_odontologia; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consultas_odontologia (id, consulta_id, tipo_denticion, comorbilidades_bucales, estudios_gabinete, indice_cpod, indice_ceod) FROM stdin;
1	4	ADULTA	Gingivitis marginal	Radiografía periapical	4	0
\.


--
-- Data for Name: consultas_psicologia; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consultas_psicologia (id, consulta_id, evaluacion_clinica, nota_evolucion, plan_intervencion) FROM stdin;
1	3	Paciente orientado en espacio y tiempo. Manifiesta inquietud psicomotriz leve y preocupación excesiva por desempeño académico.	Se establece encuadre terapéutico y rapport. Se identifican distorsiones cognitivas de tipo catastrofismo y sobregeneralización.	Psicoeducación sobre ciclo de ansiedad. Entrenamiento en respiración diafragmática 4x4. Registro semanal de emociones.
2	7	Paciente que presenta manifestaciones fisiológicas de ansiedad (taquicardia ocasional, tensión muscular) y cogniciones catastróficas asociadas a carga laboral. Afecto congruente, discurso coherente y fluido.	Primera sesión de encuadre psicoterapéutico. Se establecen metas iniciales centradas en regulación emocional y psicoeducación sobre el ciclo de la ansiedad.	1. Entrenamiento en técnicas de respiración diafragmática. 2. Registro de pensamientos automáticos disfuncionales. 3. Sesión de seguimiento en 15 días.
\.


--
-- Data for Name: curvas_crecimiento_oms; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.curvas_crecimiento_oms (id, consulta_nutricion_id, rango_edad_oms, zscore_peso_edad, zscore_talla_edad, zscore_imc_edad, percentil_calculado) FROM stdin;
1	1	5_A_19_ANOS	0.50	0.00	0.63	50
2	2	5_A_19_ANOS	0.85	0.40	0.72	75
\.


--
-- Data for Name: historias_clinicas; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.historias_clinicas (id, paciente_id, usuario_registro_id, fecha_registro, fecha_actualizacion, ahf_diabetes, ahf_hipertension, ahf_cardiopatias, ahf_neoplasias, ahf_nefropatias, ahf_enfermedades_mentales, ahf_otros, app_alergias, app_quirurgicos, app_transfusionales, app_traumaticos, app_hospitalizaciones, app_cronico_degenerativas, app_otros, apnp_tabaquismo, apnp_tabaquismo_descripcion, apnp_alcoholismo, apnp_alcoholismo_descripcion, apnp_toxicomania, apnp_vacunacion_completa, apnp_vivienda_servicios, apnp_zoonosis, apnp_actividad_fisica, ago_menarca, ago_ritmo_menstrual, ago_fum, ago_gestas, ago_partos, ago_cesareas, ago_abortos, ago_metodo_anticonceptivo, ago_papanicolaou_fecha, ago_mastografia_fecha, ago_observaciones) FROM stdin;
1	1	10	2026-10-03 00:17:49.319455	2026-10-03 00:17:49.319455	f	f	f	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	\N	\N	t	\N	\N	\N	\N	\N	\N	0	0	0	0	\N	\N	\N	\N
\.


--
-- Data for Name: pacientes; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.pacientes (id, unidad_medica_id, numero_expediente, fecha_registro, nombres, apellido_paterno, apellido_materno, curp, fecha_nacimiento, sexo, estado_civil, escolaridad, calle_numero, colonia, codigo_postal, telefono, derechohabiencia, enfermedades_previas, beneficiario_programa, nombre_programa, num_personas_vivienda, numero_afiliacion, grupo_sanguineo, religion, ocupacion, tipo_poblacion, area_servicio) FROM stdin;
1	1	EXP-2026-0001	2026-09-24 19:33:18.165792	Juan Carlos	Pérez	\N	PERJ950515HVRR01	1995-05-15	M	\N	\N	Av. Universidad 100	Centro	\N	\N	IMSS-Bienestar	\N	f	\N	1	\N	\N	\N	\N	\N	Medicina General
3	1	EXP-2026-18912	2026-09-25 18:31:58.913502	Mateo	López	García	LOGM190610HVZRRN02	2019-06-10	M	\N	\N	Av. Zaragoza 512	Centro	\N	\N	IMSS-Bienestar	\N	f	\N	1	\N	\N	\N	\N	\N	Medicina General
4	1	EXP-2026-32537	2026-09-25 21:57:12.579959	Emiliano	Domínguez	Vargas	DOVE170315HDFRRN26	2017-03-15	M	\N	\N	Av. Transístmica 810	Manuel Ávila Camacho	\N	\N	IMSS-Bienestar	\N	f	\N	1	\N	\N	\N	\N	\N	Medicina General
5	1	EXP-2026-0010	2026-09-28 19:33:31.675485	Carlos Alberto	Méndez	Cruz	MECC920410HDFRRN01	1992-04-10	M	\N	\N	Av. Lerdo 405	Puerto México	\N	\N	Ninguna	\N	f	\N	1	\N	\N	\N	\N	\N	Medicina General
6	1	EXP-2026-0011	2026-09-28 19:33:31.760038	Rosa María	Velázquez	Soto	VESR610815MDFRRN02	1961-08-15	F	\N	\N	Calle Cuauhtémoc 112	Benito Juárez Norte	\N	\N	IMSS-Bienestar	\N	f	\N	1	\N	\N	\N	\N	\N	Medicina General
7	1	EXP-2026-0012	2026-09-28 19:33:31.767292	Mateo	López	García	LOGM190220HDFRRN03	2019-02-20	M	\N	\N	Calle Costero 89	Playa Sol	\N	\N	Ninguna	\N	f	\N	1	\N	\N	\N	\N	\N	Medicina General
8	1	EXP-2026-0013	2026-09-28 19:33:31.799089	Valeria	Domínguez	Ríos	DORV140710MDFRRN04	2014-07-10	F	\N	\N	Av. Zaragoza 812	Centro	\N	\N	Ninguna	\N	f	\N	1	\N	\N	\N	\N	\N	Medicina General
9	1	EXP-2026-01617	2026-10-02 23:16:41.645728	Juan Carlos	Pérez	González	PEGJ850614HVZNNN01	1985-06-14	M	Casado/a	Secundaria	Av. Zaragoza 1204	Palma Sola	96400	9211002233	Ninguna	Hipertensión controlada	t	Salud Municipal Bienestar	4	\N	\N	\N	\N	\N	Medicina General
10	1	EXP-2026-27839	2026-10-02 23:17:07.87253	Mateo	Hernández	Cruz	HECM150910HVZRRN02	2015-09-10	M	\N	\N	Calle Hidalgo 305	Benito Juárez Norte	\N	\N	Ninguna	\N	f	\N	1	\N	\N	\N	\N	\N	Medicina General
21	1	EXP-2026-38089	2026-10-05 20:03:58.151198	Jose Eduardo	Manzano	Gallegos	123456789123456789	1999-01-01	M	Soltero(a)	Preparatoria	Av. Cuahtemoc	Centro	\N	1231231234	ISSSTE	\N	f	\N	1	\N	\N	\N	\N	\N	Medicina General
12	1	EXP-2026-29105	2026-10-05 17:58:49.147656	Carlos Alberto	Carmon	Lopez	CALC041016HTCRPRA4	1998-01-01	M	Soltero(a)	Licenciatura	Av puerto Mexico	Puerto Mexico	\N	9212808287	PEMEX	\N	f	\N	1	1431	O+	catolico	estudiante	Programa municipal	Nutrición
23	1	EXP-2026-67706	2026-10-06 22:19:27.706833	Jose	Carmona	Vargas	123456789123456780	2014-06-05	M	Soltero(a)	Primaria	av cuahtemoc 10	Puerto	\N	9211231234	IMSS	\N	f	\N	1	\N	\N	\N	\N	\N	Medicina General
24	1	EXP-2026-01855	2026-10-07 18:40:01.919248	carlos alberto	carmona	lopez	CALC041016HTCRPR04	2004-10-12	F	Soltero(a)	Licenciatura	ENRQUEZ SEGOPVIAN	CENTRO	\N	2223578858	IMSS	\N	f	\N	1	\N	\N	\N	\N	\N	Medicina General
\.


--
-- Data for Name: piezas_dentales; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.piezas_dentales (id, consulta_odontologia_id, numero_fdi, cara_vestibular, cara_lingual, cara_mesial, cara_distal, cara_oclusal, estado_general, en_puente_fijo, tiene_protesis_corona) FROM stdin;
1	1	18	SANO	SANO	SANO	SANO	CARIES	NORMAL	f	f
2	1	17	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
3	1	16	SANO	SANO	RESINA	SANO	SANO	NORMAL	f	f
4	1	15	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
5	1	14	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
6	1	13	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
7	1	12	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
8	1	11	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
9	1	21	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
10	1	22	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
11	1	23	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
12	1	24	SANO	SANO	SANO	SANO	SANO	AUSENTE	f	f
13	1	25	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
14	1	26	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
15	1	27	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
16	1	28	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
17	1	48	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
18	1	47	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
19	1	46	SANO	SANO	SANO	SANO	SANO	EXTRACCION	f	f
20	1	45	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
21	1	44	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
22	1	43	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
23	1	42	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
24	1	41	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
25	1	31	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
26	1	32	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
27	1	33	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
28	1	34	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
29	1	35	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
30	1	36	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
31	1	37	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
32	1	38	SANO	SANO	SANO	SANO	SANO	NORMAL	f	f
\.


--
-- Data for Name: procedimientos_enfermeria; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.procedimientos_enfermeria (id, triaje_id, tipo_procedimiento, cantidad, observaciones) FROM stdin;
1	1	Curación menor	1	Asepsia en raspón superficial de antebrazo
2	2	Toma de glucosa capilar	1	Ayuno de 8 horas
3	2	Curación menor	1	Asepsia en herida superficial de antebrazo
4	5	Toma de Glucosa Capilar	1	Ayuno de 8 hrs
5	5	Inyección Intramuscular	1	Analgésico
\.


--
-- Data for Name: reportes_estadisticos_mensuales; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.reportes_estadisticos_mensuales (id, unidad_medica_id, mes, anio, total_consultas, total_primeras_veces, total_subsecuentes, desglose_sexo, desglose_grupos_edad, desglose_morbilidad, cuadre_valido, fecha_generacion) FROM stdin;
1	1	9	2026	8	5	3	{"femenino": 0, "masculino": 8}	{"de_1_a_4": 0, "de_5_a_14": 2, "de_15_a_29": 0, "de_30_a_59": 6, "mayores_60": 0, "menores_1_ano": 0}	{"Consulta General / Valoración": 8, "Infecciones Respiratorias Agudas": 1, "Infecciones respiratorias agudas": 1}	t	2026-09-25 22:00:00.488892
\.


--
-- Data for Name: tratamientos_cruzados; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.tratamientos_cruzados (id, atencion_origen_id, area_origen, area_destino, prioridad, motivo_derivacion, estado, fecha_hora_derivacion) FROM stdin;
1	1	MEDICINA_GENERAL	NUTRICION	NORMAL	Derivación preventiva por percentil de bajo peso detectado en somatometría de triaje (IMC 16.5).	ATENDIDO	2026-09-25 19:01:06.227023
3	7	MEDICINA_GENERAL	ODONTOLOGIA	NORMAL	Revisión bucodental preventiva.	PENDIENTE	2026-09-25 21:00:37.830591
2	7	MEDICINA_GENERAL	NUTRICION	URGENTE	Glucosa alterada en ayuno y sobrepeso severo. Requiere plan de manejo nutricional urgente.	ATENDIDO	2026-09-25 21:00:37.691691
4	11	MEDICINA_GENERAL	NUTRICION	URGENTE	Paciente con sospecha de síndrome metabólico (T/A 145/95 y glucosa 135 mg/dL). Requiere valoración prioritaria.	PENDIENTE	2026-09-28 19:33:31.891727
\.


--
-- Data for Name: triaje_signos_vitales; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.triaje_signos_vitales (id, atencion_id, enfermero_id, tension_arterial, frecuencia_cardiaca, frecuencia_respiratoria, temperatura, saturacion_oxigeno, glucosa_capilar, peso_kg, talla_metros, imc, clasificacion_imc, detecciones_riesgo, fecha_hora) FROM stdin;
1	1	4	110/70	78	18	36.6	98	85	24.50	1.22	16.5	Bajo peso	Sin antecedentes de riesgo detectados en tamizaje	2026-09-25 18:53:07.213228
2	5	1	120/80	72	16	36.5	99	95	70.00	1.72	23.7	Normal	Sin antecedentes de riesgo. Detección de hipertensión negativa.	2026-09-25 20:49:31.854852
3	10	10	120/80	74	16	36.6	99	92	75.00	1.74	24.8	Normal	Sin comorbilidades agudas	2026-09-28 19:33:31.836791
4	11	10	145/95	86	18	37.0	96	135	68.00	1.58	27.2	Sobrepeso	Hipertensión grado 1 en detección	2026-09-28 19:33:31.86354
5	12	10	120/80	75	18	36.6	98	95	70.00	1.70	24.2	Normal	Sin comorbilidad crítica	2026-10-02 23:22:25.84416
6	14	10	120/80	75	18	36.5	98	\N	85.00	1.73	28.4	Sobrepeso	\N	2026-10-06 21:38:53.311118
7	8	10	120/80	75	18	36.5	98	\N	50.00	1.54	21.1	Normal	\N	2026-10-06 21:55:00.193464
8	15	10	120/80	75	18	36.5	98	\N	172.00	0.90	212.3	Obesidad Grado III	\N	2026-10-06 22:02:20.907865
9	16	10	120/80	75	18	36.5	98	\N	69.00	1.60	27.0	Sobrepeso	esta palido	2026-10-06 22:21:15.487198
10	17	10	10/80	90	18	37.0	95	200	85.00	1.72	28.7	Sobrepeso	complexion muscular correcta , sin sobrepesop	2026-10-07 19:39:49.819527
\.


--
-- Data for Name: tutores; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.tutores (id, paciente_id, nombre_completo, parentesco, telefono_contacto, tipo_identificacion, numero_identificacion) FROM stdin;
1	3	María Elena García Ramos	Madre	9211234567	INE	ID-INE-998877
2	4	Carmen Vargas Reyes	Madre	9211112233	Pasaporte	PAS-MEX-7788
4	7	Valeria García Santos	Madre	9212154433	INE	INE-VER-8822
5	8	Fernando Domínguez Luna	Padre	9211334455	INE	INE-VER-3311
6	10	Carmen Cruz Santos	Madre	9211554433	INE	0847129845123
7	23	camronsita	Madre	1234567890	INE	\N
\.


--
-- Data for Name: unidades_medicas; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.unidades_medicas (id, nombre, clave_oficial, direccion, colonia, telefono, georreferencia, activo) FROM stdin;
1	Dirección de Salud Pública Municipal - Sede Central	DSPM-COATZA-01	Av. Hilario Rodríguez Malpica 402, Centro	Centro	9212112100	\N	t
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.usuarios (id, unidad_medica_id, nombre, apellidos, email, password_hash, rol, cedula_profesional, activo, ultimo_acceso) FROM stdin;
11	1	Dr. Carlos	Gómez Herrera	medico@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	MEDICO_GENERAL	MED-303	t	2026-10-05 17:20:48.05686
1	1	Administrador	Sistema Clinix	admin@clinix.coatzacoalcos.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.j2fmyYM.ycQtKnsxJIh0qVDqz/qyIOG	DIRECCION	ADMIN-001	t	2026-09-28 18:29:10.242266
12	1	Dra. Brenda	Castillo Lara	odonto@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	ODONTOLOGO	ODO-404	t	\N
13	1	L.N. Daniela	Peralta Silva	nutri@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	NUTRIOLOGO	NUT-505	t	\N
14	1	Psic. Jorge	Morales Díaz	psico@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	PSICOLOGO	PSI-606	t	\N
4	1	Carlos	Vargas Luna	carlos.enfermeria@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	ENFERMERIA	ENF-445566	t	2026-09-25 18:53:06.969886
2	1	Ana Laura	Martínez Ramos	ana.martinez@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	MEDICO_GENERAL	CED-893412	t	2026-09-25 19:01:05.939
5	1	Diego	Herrera Castillo	diego.nutricion@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	NUTRIOLOGO	NUT-778899	t	2026-09-25 19:07:52.155452
8	1	Dr. Roberto	Alor Vázquez	admin@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	DIRECCION	DIR-001	t	\N
3	1	Sofía	Gómez Hernández	sofia.recepcion@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	RECEPCION	\N	t	2026-09-25 19:15:10.648367
6	1	Valeria	Morales Cruz	valeria.psicologia@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	PSICOLOGO	PSI-332211	t	2026-09-25 19:18:59.829939
7	1	Dra. Patricia	Sánchez Enríquez	directora.salud@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	DIRECCION	DIR-100200	t	2026-09-25 19:29:47.085559
15	1	Dr. Alejandro	Ramírez Solís	dr.nuevo.1790977783475@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	MEDICO_GENERAL	CED-MED-9944	f	\N
9	1	María Elena	Cruz Santos	recepcion@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	RECEPCION	REC-101	t	2026-10-07 23:04:29.083748
10	1	Lic. Sofía	Mendoza Ramos	enfermeria@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	ENFERMERIA	ENF-202	t	2026-10-07 23:10:57.371117
\.


--
-- Name: atenciones_clinicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.atenciones_clinicas_id_seq', 17, true);


--
-- Name: bitacora_productividad_diaria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.bitacora_productividad_diaria_id_seq', 4, true);


--
-- Name: consentimientos_informados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consentimientos_informados_id_seq', 3, true);


--
-- Name: consultas_base_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consultas_base_id_seq', 8, true);


--
-- Name: consultas_medicina_general_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consultas_medicina_general_id_seq', 3, true);


--
-- Name: consultas_nutricion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consultas_nutricion_id_seq', 2, true);


--
-- Name: consultas_odontologia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consultas_odontologia_id_seq', 1, true);


--
-- Name: consultas_psicologia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consultas_psicologia_id_seq', 2, true);


--
-- Name: curvas_crecimiento_oms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.curvas_crecimiento_oms_id_seq', 2, true);


--
-- Name: historias_clinicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.historias_clinicas_id_seq', 1, true);


--
-- Name: pacientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.pacientes_id_seq', 24, true);


--
-- Name: piezas_dentales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.piezas_dentales_id_seq', 32, true);


--
-- Name: procedimientos_enfermeria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.procedimientos_enfermeria_id_seq', 5, true);


--
-- Name: reportes_estadisticos_mensuales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.reportes_estadisticos_mensuales_id_seq', 2, true);


--
-- Name: tratamientos_cruzados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.tratamientos_cruzados_id_seq', 4, true);


--
-- Name: triaje_signos_vitales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.triaje_signos_vitales_id_seq', 10, true);


--
-- Name: tutores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.tutores_id_seq', 9, true);


--
-- Name: unidades_medicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.unidades_medicas_id_seq', 1, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 15, true);


--
-- Name: atenciones_clinicas atenciones_clinicas_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.atenciones_clinicas
    ADD CONSTRAINT atenciones_clinicas_pkey PRIMARY KEY (id);


--
-- Name: bitacora_productividad_diaria bitacora_productividad_diaria_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.bitacora_productividad_diaria
    ADD CONSTRAINT bitacora_productividad_diaria_pkey PRIMARY KEY (id);


--
-- Name: consentimientos_informados consentimientos_informados_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consentimientos_informados
    ADD CONSTRAINT consentimientos_informados_pkey PRIMARY KEY (id);


--
-- Name: consultas_base consultas_base_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_base
    ADD CONSTRAINT consultas_base_pkey PRIMARY KEY (id);


--
-- Name: consultas_medicina_general consultas_medicina_general_consulta_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_medicina_general
    ADD CONSTRAINT consultas_medicina_general_consulta_id_key UNIQUE (consulta_id);


--
-- Name: consultas_medicina_general consultas_medicina_general_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_medicina_general
    ADD CONSTRAINT consultas_medicina_general_pkey PRIMARY KEY (id);


--
-- Name: consultas_nutricion consultas_nutricion_consulta_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_nutricion
    ADD CONSTRAINT consultas_nutricion_consulta_id_key UNIQUE (consulta_id);


--
-- Name: consultas_nutricion consultas_nutricion_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_nutricion
    ADD CONSTRAINT consultas_nutricion_pkey PRIMARY KEY (id);


--
-- Name: consultas_odontologia consultas_odontologia_consulta_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_odontologia
    ADD CONSTRAINT consultas_odontologia_consulta_id_key UNIQUE (consulta_id);


--
-- Name: consultas_odontologia consultas_odontologia_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_odontologia
    ADD CONSTRAINT consultas_odontologia_pkey PRIMARY KEY (id);


--
-- Name: consultas_psicologia consultas_psicologia_consulta_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_psicologia
    ADD CONSTRAINT consultas_psicologia_consulta_id_key UNIQUE (consulta_id);


--
-- Name: consultas_psicologia consultas_psicologia_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_psicologia
    ADD CONSTRAINT consultas_psicologia_pkey PRIMARY KEY (id);


--
-- Name: curvas_crecimiento_oms curvas_crecimiento_oms_consulta_nutricion_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.curvas_crecimiento_oms
    ADD CONSTRAINT curvas_crecimiento_oms_consulta_nutricion_id_key UNIQUE (consulta_nutricion_id);


--
-- Name: curvas_crecimiento_oms curvas_crecimiento_oms_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.curvas_crecimiento_oms
    ADD CONSTRAINT curvas_crecimiento_oms_pkey PRIMARY KEY (id);


--
-- Name: historias_clinicas historias_clinicas_paciente_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.historias_clinicas
    ADD CONSTRAINT historias_clinicas_paciente_id_key UNIQUE (paciente_id);


--
-- Name: historias_clinicas historias_clinicas_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.historias_clinicas
    ADD CONSTRAINT historias_clinicas_pkey PRIMARY KEY (id);


--
-- Name: pacientes pacientes_curp_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_curp_key UNIQUE (curp);


--
-- Name: pacientes pacientes_numero_expediente_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_numero_expediente_key UNIQUE (numero_expediente);


--
-- Name: pacientes pacientes_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_pkey PRIMARY KEY (id);


--
-- Name: piezas_dentales piezas_dentales_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.piezas_dentales
    ADD CONSTRAINT piezas_dentales_pkey PRIMARY KEY (id);


--
-- Name: procedimientos_enfermeria procedimientos_enfermeria_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.procedimientos_enfermeria
    ADD CONSTRAINT procedimientos_enfermeria_pkey PRIMARY KEY (id);


--
-- Name: reportes_estadisticos_mensuales reportes_estadisticos_mensuales_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.reportes_estadisticos_mensuales
    ADD CONSTRAINT reportes_estadisticos_mensuales_pkey PRIMARY KEY (id);


--
-- Name: tratamientos_cruzados tratamientos_cruzados_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tratamientos_cruzados
    ADD CONSTRAINT tratamientos_cruzados_pkey PRIMARY KEY (id);


--
-- Name: triaje_signos_vitales triaje_signos_vitales_atencion_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.triaje_signos_vitales
    ADD CONSTRAINT triaje_signos_vitales_atencion_id_key UNIQUE (atencion_id);


--
-- Name: triaje_signos_vitales triaje_signos_vitales_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.triaje_signos_vitales
    ADD CONSTRAINT triaje_signos_vitales_pkey PRIMARY KEY (id);


--
-- Name: tutores tutores_paciente_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tutores
    ADD CONSTRAINT tutores_paciente_id_key UNIQUE (paciente_id);


--
-- Name: tutores tutores_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tutores
    ADD CONSTRAINT tutores_pkey PRIMARY KEY (id);


--
-- Name: unidades_medicas unidades_medicas_clave_oficial_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.unidades_medicas
    ADD CONSTRAINT unidades_medicas_clave_oficial_key UNIQUE (clave_oficial);


--
-- Name: unidades_medicas unidades_medicas_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.unidades_medicas
    ADD CONSTRAINT unidades_medicas_pkey PRIMARY KEY (id);


--
-- Name: bitacora_productividad_diaria uq_bitacora_usuario_fecha; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.bitacora_productividad_diaria
    ADD CONSTRAINT uq_bitacora_usuario_fecha UNIQUE (usuario_id, fecha);


--
-- Name: reportes_estadisticos_mensuales uq_reporte_unidad_periodo; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.reportes_estadisticos_mensuales
    ADD CONSTRAINT uq_reporte_unidad_periodo UNIQUE (unidad_medica_id, mes, anio);


--
-- Name: usuarios usuarios_email_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_email_key UNIQUE (email);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: idx_atenciones_estado; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_atenciones_estado ON public.atenciones_clinicas USING btree (estado);


--
-- Name: idx_atenciones_paciente_fecha; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_atenciones_paciente_fecha ON public.atenciones_clinicas USING btree (paciente_id, fecha_hora_ingreso DESC);


--
-- Name: idx_bitacora_fecha; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_bitacora_fecha ON public.bitacora_productividad_diaria USING btree (fecha);


--
-- Name: idx_consultas_base_atencion; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_consultas_base_atencion ON public.consultas_base USING btree (atencion_id);


--
-- Name: idx_historias_clinicas_paciente; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_historias_clinicas_paciente ON public.historias_clinicas USING btree (paciente_id);


--
-- Name: idx_pacientes_curp; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_pacientes_curp ON public.pacientes USING btree (curp);


--
-- Name: idx_pacientes_expediente; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_pacientes_expediente ON public.pacientes USING btree (numero_expediente);


--
-- Name: idx_pacientes_nombre; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_pacientes_nombre ON public.pacientes USING btree (apellido_paterno, apellido_materno, nombres);


--
-- Name: idx_piezas_dentales_consulta; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_piezas_dentales_consulta ON public.piezas_dentales USING btree (consulta_odontologia_id);


--
-- Name: idx_reportes_periodo; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_reportes_periodo ON public.reportes_estadisticos_mensuales USING btree (anio, mes);


--
-- Name: atenciones_clinicas atenciones_clinicas_paciente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.atenciones_clinicas
    ADD CONSTRAINT atenciones_clinicas_paciente_id_fkey FOREIGN KEY (paciente_id) REFERENCES public.pacientes(id) ON DELETE RESTRICT;


--
-- Name: atenciones_clinicas atenciones_clinicas_unidad_medica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.atenciones_clinicas
    ADD CONSTRAINT atenciones_clinicas_unidad_medica_id_fkey FOREIGN KEY (unidad_medica_id) REFERENCES public.unidades_medicas(id) ON DELETE RESTRICT;


--
-- Name: atenciones_clinicas atenciones_clinicas_usuario_recepcion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.atenciones_clinicas
    ADD CONSTRAINT atenciones_clinicas_usuario_recepcion_id_fkey FOREIGN KEY (usuario_recepcion_id) REFERENCES public.usuarios(id) ON DELETE RESTRICT;


--
-- Name: bitacora_productividad_diaria bitacora_productividad_diaria_unidad_medica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.bitacora_productividad_diaria
    ADD CONSTRAINT bitacora_productividad_diaria_unidad_medica_id_fkey FOREIGN KEY (unidad_medica_id) REFERENCES public.unidades_medicas(id) ON DELETE RESTRICT;


--
-- Name: bitacora_productividad_diaria bitacora_productividad_diaria_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.bitacora_productividad_diaria
    ADD CONSTRAINT bitacora_productividad_diaria_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON DELETE RESTRICT;


--
-- Name: consentimientos_informados consentimientos_informados_consulta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consentimientos_informados
    ADD CONSTRAINT consentimientos_informados_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas_base(id) ON DELETE CASCADE;


--
-- Name: consentimientos_informados consentimientos_informados_paciente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consentimientos_informados
    ADD CONSTRAINT consentimientos_informados_paciente_id_fkey FOREIGN KEY (paciente_id) REFERENCES public.pacientes(id) ON DELETE RESTRICT;


--
-- Name: consentimientos_informados consentimientos_informados_tutor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consentimientos_informados
    ADD CONSTRAINT consentimientos_informados_tutor_id_fkey FOREIGN KEY (tutor_id) REFERENCES public.tutores(id) ON DELETE RESTRICT;


--
-- Name: consultas_base consultas_base_atencion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_base
    ADD CONSTRAINT consultas_base_atencion_id_fkey FOREIGN KEY (atencion_id) REFERENCES public.atenciones_clinicas(id) ON DELETE RESTRICT;


--
-- Name: consultas_base consultas_base_especialista_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_base
    ADD CONSTRAINT consultas_base_especialista_id_fkey FOREIGN KEY (especialista_id) REFERENCES public.usuarios(id) ON DELETE RESTRICT;


--
-- Name: consultas_medicina_general consultas_medicina_general_consulta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_medicina_general
    ADD CONSTRAINT consultas_medicina_general_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas_base(id) ON DELETE CASCADE;


--
-- Name: consultas_nutricion consultas_nutricion_consulta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_nutricion
    ADD CONSTRAINT consultas_nutricion_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas_base(id) ON DELETE CASCADE;


--
-- Name: consultas_odontologia consultas_odontologia_consulta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_odontologia
    ADD CONSTRAINT consultas_odontologia_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas_base(id) ON DELETE CASCADE;


--
-- Name: consultas_psicologia consultas_psicologia_consulta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_psicologia
    ADD CONSTRAINT consultas_psicologia_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas_base(id) ON DELETE CASCADE;


--
-- Name: curvas_crecimiento_oms curvas_crecimiento_oms_consulta_nutricion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.curvas_crecimiento_oms
    ADD CONSTRAINT curvas_crecimiento_oms_consulta_nutricion_id_fkey FOREIGN KEY (consulta_nutricion_id) REFERENCES public.consultas_nutricion(id) ON DELETE CASCADE;


--
-- Name: historias_clinicas historias_clinicas_paciente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.historias_clinicas
    ADD CONSTRAINT historias_clinicas_paciente_id_fkey FOREIGN KEY (paciente_id) REFERENCES public.pacientes(id) ON DELETE CASCADE;


--
-- Name: historias_clinicas historias_clinicas_usuario_registro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.historias_clinicas
    ADD CONSTRAINT historias_clinicas_usuario_registro_id_fkey FOREIGN KEY (usuario_registro_id) REFERENCES public.usuarios(id) ON DELETE SET NULL;


--
-- Name: pacientes pacientes_unidad_medica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_unidad_medica_id_fkey FOREIGN KEY (unidad_medica_id) REFERENCES public.unidades_medicas(id) ON DELETE RESTRICT;


--
-- Name: piezas_dentales piezas_dentales_consulta_odontologia_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.piezas_dentales
    ADD CONSTRAINT piezas_dentales_consulta_odontologia_id_fkey FOREIGN KEY (consulta_odontologia_id) REFERENCES public.consultas_odontologia(id) ON DELETE CASCADE;


--
-- Name: procedimientos_enfermeria procedimientos_enfermeria_triaje_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.procedimientos_enfermeria
    ADD CONSTRAINT procedimientos_enfermeria_triaje_id_fkey FOREIGN KEY (triaje_id) REFERENCES public.triaje_signos_vitales(id) ON DELETE CASCADE;


--
-- Name: reportes_estadisticos_mensuales reportes_estadisticos_mensuales_unidad_medica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.reportes_estadisticos_mensuales
    ADD CONSTRAINT reportes_estadisticos_mensuales_unidad_medica_id_fkey FOREIGN KEY (unidad_medica_id) REFERENCES public.unidades_medicas(id) ON DELETE RESTRICT;


--
-- Name: tratamientos_cruzados tratamientos_cruzados_atencion_origen_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tratamientos_cruzados
    ADD CONSTRAINT tratamientos_cruzados_atencion_origen_id_fkey FOREIGN KEY (atencion_origen_id) REFERENCES public.atenciones_clinicas(id) ON DELETE RESTRICT;


--
-- Name: triaje_signos_vitales triaje_signos_vitales_atencion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.triaje_signos_vitales
    ADD CONSTRAINT triaje_signos_vitales_atencion_id_fkey FOREIGN KEY (atencion_id) REFERENCES public.atenciones_clinicas(id) ON DELETE CASCADE;


--
-- Name: triaje_signos_vitales triaje_signos_vitales_enfermero_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.triaje_signos_vitales
    ADD CONSTRAINT triaje_signos_vitales_enfermero_id_fkey FOREIGN KEY (enfermero_id) REFERENCES public.usuarios(id) ON DELETE RESTRICT;


--
-- Name: tutores tutores_paciente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tutores
    ADD CONSTRAINT tutores_paciente_id_fkey FOREIGN KEY (paciente_id) REFERENCES public.pacientes(id) ON DELETE CASCADE;


--
-- Name: usuarios usuarios_unidad_medica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_unidad_medica_id_fkey FOREIGN KEY (unidad_medica_id) REFERENCES public.unidades_medicas(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict Tz02pjvn2f4ObAgWIz0sh4r9kScnSyzyrZKdZTu12T5a4e2xTsLDFNv1ayP4ac6

