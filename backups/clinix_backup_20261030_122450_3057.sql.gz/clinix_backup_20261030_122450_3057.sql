--
-- PostgreSQL database dump
--

\restrict e0nRhGNGNwr8CjsRhrjkuwXj68qGcjPDe6ycfN3fY7YPSAaBfjZ64mvwnjOiOhc

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: atenciones_clinicas; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.atenciones_clinicas (
    id integer NOT NULL,
    paciente_id integer NOT NULL,
    unidad_medica_id integer NOT NULL,
    usuario_recepcion_id integer NOT NULL,
    fecha_hora_ingreso timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tipo_atencion character varying(20) NOT NULL,
    estado character varying(30) NOT NULL,
    area_servicio character varying(100) DEFAULT 'Medicina General'::character varying,
    CONSTRAINT atenciones_clinicas_estado_check CHECK (((estado)::text = ANY ((ARRAY['RECEPCION'::character varying, 'TRIAJE'::character varying, 'EN_CONSULTA'::character varying, 'FINALIZADA'::character varying])::text[]))),
    CONSTRAINT atenciones_clinicas_tipo_atencion_check CHECK (((tipo_atencion)::text = ANY ((ARRAY['PRIMERA_VEZ'::character varying, 'SUBSECUENTE'::character varying])::text[])))
);


ALTER TABLE public.atenciones_clinicas OWNER TO clinix_user;

--
-- Name: atenciones_clinicas_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.atenciones_clinicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.atenciones_clinicas_id_seq OWNER TO clinix_user;

--
-- Name: atenciones_clinicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.atenciones_clinicas_id_seq OWNED BY public.atenciones_clinicas.id;


--
-- Name: bitacora_productividad_diaria; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.bitacora_productividad_diaria (
    id integer NOT NULL,
    usuario_id integer NOT NULL,
    unidad_medica_id integer NOT NULL,
    fecha date NOT NULL,
    total_atenciones integer DEFAULT 0 NOT NULL,
    desglose_servicios jsonb
);


ALTER TABLE public.bitacora_productividad_diaria OWNER TO clinix_user;

--
-- Name: bitacora_productividad_diaria_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.bitacora_productividad_diaria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bitacora_productividad_diaria_id_seq OWNER TO clinix_user;

--
-- Name: bitacora_productividad_diaria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.bitacora_productividad_diaria_id_seq OWNED BY public.bitacora_productividad_diaria.id;


--
-- Name: consentimientos_informados; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consentimientos_informados (
    id integer NOT NULL,
    consulta_id integer NOT NULL,
    paciente_id integer NOT NULL,
    tutor_id integer,
    grupo_edad character varying(20) NOT NULL,
    texto_legal text NOT NULL,
    firmado boolean DEFAULT false NOT NULL,
    fecha_firma timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT consentimientos_informados_grupo_edad_check CHECK (((grupo_edad)::text = ANY ((ARRAY['INFANTIL'::character varying, 'ADOLESCENTE'::character varying, 'ADULTO'::character varying])::text[])))
);


ALTER TABLE public.consentimientos_informados OWNER TO clinix_user;

--
-- Name: consentimientos_informados_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consentimientos_informados_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consentimientos_informados_id_seq OWNER TO clinix_user;

--
-- Name: consentimientos_informados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consentimientos_informados_id_seq OWNED BY public.consentimientos_informados.id;


--
-- Name: consultas_base; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consultas_base (
    id integer NOT NULL,
    atencion_id integer NOT NULL,
    especialista_id integer NOT NULL,
    area_medica character varying(30) NOT NULL,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    motivo_consulta text NOT NULL,
    observaciones text,
    CONSTRAINT consultas_base_area_medica_check CHECK (((area_medica)::text = ANY ((ARRAY['MEDICINA_GENERAL'::character varying, 'ODONTOLOGIA'::character varying, 'NUTRICION'::character varying, 'PSICOLOGIA'::character varying])::text[])))
);


ALTER TABLE public.consultas_base OWNER TO clinix_user;

--
-- Name: consultas_base_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consultas_base_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consultas_base_id_seq OWNER TO clinix_user;

--
-- Name: consultas_base_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consultas_base_id_seq OWNED BY public.consultas_base.id;


--
-- Name: consultas_medicina_general; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consultas_medicina_general (
    id integer NOT NULL,
    consulta_id integer NOT NULL,
    nota_subjetivo text NOT NULL,
    nota_objetivo text NOT NULL,
    nota_analisis text NOT NULL,
    nota_plan text NOT NULL,
    diagnostico_cie10 character varying(10) NOT NULL,
    diagnostico_descripcion character varying(200) NOT NULL,
    clasificacion_morbilidad character varying(60) NOT NULL,
    pruebas_rapidas character varying(150),
    canalizacion_externa character varying(60),
    emite_certificado boolean DEFAULT false NOT NULL
);


ALTER TABLE public.consultas_medicina_general OWNER TO clinix_user;

--
-- Name: consultas_medicina_general_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consultas_medicina_general_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consultas_medicina_general_id_seq OWNER TO clinix_user;

--
-- Name: consultas_medicina_general_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consultas_medicina_general_id_seq OWNED BY public.consultas_medicina_general.id;


--
-- Name: consultas_nutricion; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consultas_nutricion (
    id integer NOT NULL,
    consulta_id integer NOT NULL,
    circunferencia_cintura numeric(5,1),
    circunferencia_cadera numeric(5,1),
    circunferencia_brazo numeric(4,1),
    porcentaje_grasa numeric(4,1),
    porcentaje_musculo numeric(4,1),
    consumo_agua_litros numeric(3,1),
    frecuencia_ejercicio character varying(60),
    recordatorio_24h jsonb,
    antecedentes_patologicos jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.consultas_nutricion OWNER TO clinix_user;

--
-- Name: consultas_nutricion_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consultas_nutricion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consultas_nutricion_id_seq OWNER TO clinix_user;

--
-- Name: consultas_nutricion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consultas_nutricion_id_seq OWNED BY public.consultas_nutricion.id;


--
-- Name: consultas_odontologia; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consultas_odontologia (
    id integer NOT NULL,
    consulta_id integer NOT NULL,
    tipo_denticion character varying(20) NOT NULL,
    comorbilidades_bucales text,
    estudios_gabinete character varying(150),
    indice_cpod smallint DEFAULT 0 NOT NULL,
    indice_ceod smallint DEFAULT 0 NOT NULL,
    CONSTRAINT consultas_odontologia_tipo_denticion_check CHECK (((tipo_denticion)::text = ANY ((ARRAY['ADULTA'::character varying, 'INFANTIL'::character varying])::text[])))
);


ALTER TABLE public.consultas_odontologia OWNER TO clinix_user;

--
-- Name: consultas_odontologia_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consultas_odontologia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consultas_odontologia_id_seq OWNER TO clinix_user;

--
-- Name: consultas_odontologia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consultas_odontologia_id_seq OWNED BY public.consultas_odontologia.id;


--
-- Name: consultas_psicologia; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.consultas_psicologia (
    id integer NOT NULL,
    consulta_id integer NOT NULL,
    evaluacion_clinica text NOT NULL,
    nota_evolucion text NOT NULL,
    plan_intervencion text NOT NULL
);


ALTER TABLE public.consultas_psicologia OWNER TO clinix_user;

--
-- Name: consultas_psicologia_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.consultas_psicologia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.consultas_psicologia_id_seq OWNER TO clinix_user;

--
-- Name: consultas_psicologia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.consultas_psicologia_id_seq OWNED BY public.consultas_psicologia.id;


--
-- Name: curvas_crecimiento_oms; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.curvas_crecimiento_oms (
    id integer NOT NULL,
    consulta_nutricion_id integer NOT NULL,
    rango_edad_oms character varying(20) NOT NULL,
    zscore_peso_edad numeric(4,2),
    zscore_talla_edad numeric(4,2),
    zscore_imc_edad numeric(4,2),
    percentil_calculado smallint,
    CONSTRAINT curvas_crecimiento_oms_rango_edad_oms_check CHECK (((rango_edad_oms)::text = ANY ((ARRAY['2_A_5_ANOS'::character varying, '5_A_19_ANOS'::character varying])::text[])))
);


ALTER TABLE public.curvas_crecimiento_oms OWNER TO clinix_user;

--
-- Name: curvas_crecimiento_oms_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.curvas_crecimiento_oms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.curvas_crecimiento_oms_id_seq OWNER TO clinix_user;

--
-- Name: curvas_crecimiento_oms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.curvas_crecimiento_oms_id_seq OWNED BY public.curvas_crecimiento_oms.id;


--
-- Name: historias_clinicas; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.historias_clinicas (
    id integer NOT NULL,
    paciente_id integer NOT NULL,
    usuario_registro_id integer,
    fecha_registro timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    fecha_actualizacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ahf_diabetes boolean DEFAULT false NOT NULL,
    ahf_hipertension boolean DEFAULT false NOT NULL,
    ahf_cardiopatias boolean DEFAULT false NOT NULL,
    ahf_neoplasias boolean DEFAULT false NOT NULL,
    ahf_nefropatias boolean DEFAULT false NOT NULL,
    ahf_enfermedades_mentales boolean DEFAULT false NOT NULL,
    ahf_otros text,
    app_alergias text,
    app_quirurgicos text,
    app_transfusionales text,
    app_traumaticos text,
    app_hospitalizaciones text,
    app_cronico_degenerativas text,
    app_otros text,
    apnp_tabaquismo boolean DEFAULT false NOT NULL,
    apnp_tabaquismo_descripcion character varying(150),
    apnp_alcoholismo boolean DEFAULT false NOT NULL,
    apnp_alcoholismo_descripcion character varying(150),
    apnp_toxicomania text,
    apnp_vacunacion_completa boolean DEFAULT true NOT NULL,
    apnp_vivienda_servicios character varying(250),
    apnp_zoonosis character varying(150),
    apnp_actividad_fisica character varying(100),
    ago_menarca smallint,
    ago_ritmo_menstrual character varying(30),
    ago_fum date,
    ago_gestas smallint DEFAULT 0,
    ago_partos smallint DEFAULT 0,
    ago_cesareas smallint DEFAULT 0,
    ago_abortos smallint DEFAULT 0,
    ago_metodo_anticonceptivo character varying(100),
    ago_papanicolaou_fecha date,
    ago_mastografia_fecha date,
    ago_observaciones text,
    CONSTRAINT historias_clinicas_ago_abortos_check CHECK ((ago_abortos >= 0)),
    CONSTRAINT historias_clinicas_ago_cesareas_check CHECK ((ago_cesareas >= 0)),
    CONSTRAINT historias_clinicas_ago_gestas_check CHECK ((ago_gestas >= 0)),
    CONSTRAINT historias_clinicas_ago_menarca_check CHECK (((ago_menarca >= 8) AND (ago_menarca <= 25))),
    CONSTRAINT historias_clinicas_ago_partos_check CHECK ((ago_partos >= 0))
);


ALTER TABLE public.historias_clinicas OWNER TO clinix_user;

--
-- Name: historias_clinicas_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.historias_clinicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.historias_clinicas_id_seq OWNER TO clinix_user;

--
-- Name: historias_clinicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.historias_clinicas_id_seq OWNED BY public.historias_clinicas.id;


--
-- Name: oms_referencia_imc; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.oms_referencia_imc (
    edad integer NOT NULL,
    sexo character varying(1) NOT NULL,
    sd_menos_3 numeric(5,2) NOT NULL,
    sd_menos_2 numeric(5,2) NOT NULL,
    sd_menos_1 numeric(5,2) NOT NULL,
    mediana numeric(5,2) NOT NULL,
    sd_mas_1 numeric(5,2) NOT NULL,
    sd_mas_2 numeric(5,2) NOT NULL,
    sd_mas_3 numeric(5,2) NOT NULL
);


ALTER TABLE public.oms_referencia_imc OWNER TO clinix_user;

--
-- Name: pacientes; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.pacientes (
    id integer NOT NULL,
    unidad_medica_id integer NOT NULL,
    numero_expediente character varying(30) NOT NULL,
    fecha_registro timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    nombres character varying(80) NOT NULL,
    apellido_paterno character varying(60) NOT NULL,
    apellido_materno character varying(60),
    curp character varying(18) NOT NULL,
    fecha_nacimiento date NOT NULL,
    sexo character(1) NOT NULL,
    estado_civil character varying(25),
    escolaridad character varying(40),
    calle_numero character varying(150) NOT NULL,
    colonia character varying(100) NOT NULL,
    codigo_postal character varying(5),
    telefono character varying(15),
    derechohabiencia character varying(50) NOT NULL,
    enfermedades_previas text,
    beneficiario_programa boolean DEFAULT false NOT NULL,
    nombre_programa character varying(100),
    num_personas_vivienda smallint DEFAULT 1 NOT NULL,
    numero_afiliacion character varying(100),
    grupo_sanguineo character varying(50),
    religion character varying(100),
    ocupacion character varying(100),
    tipo_poblacion character varying(100),
    area_servicio character varying(100) DEFAULT 'Medicina General'::character varying,
    CONSTRAINT pacientes_derechohabiencia_check CHECK (((derechohabiencia)::text = ANY ((ARRAY['IMSS'::character varying, 'ISSSTE'::character varying, 'PEMEX'::character varying, 'SEDENA'::character varying, 'SEMAR'::character varying, 'IMSS-Bienestar'::character varying, 'Ninguna'::character varying])::text[]))),
    CONSTRAINT pacientes_num_personas_vivienda_check CHECK ((num_personas_vivienda >= 1)),
    CONSTRAINT pacientes_sexo_check CHECK ((sexo = ANY (ARRAY['M'::bpchar, 'F'::bpchar])))
);


ALTER TABLE public.pacientes OWNER TO clinix_user;

--
-- Name: pacientes_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.pacientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pacientes_id_seq OWNER TO clinix_user;

--
-- Name: pacientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.pacientes_id_seq OWNED BY public.pacientes.id;


--
-- Name: piezas_dentales; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.piezas_dentales (
    id integer NOT NULL,
    consulta_odontologia_id integer NOT NULL,
    numero_fdi smallint NOT NULL,
    cara_vestibular character varying(15) DEFAULT 'SANO'::character varying,
    cara_lingual character varying(15) DEFAULT 'SANO'::character varying,
    cara_mesial character varying(15) DEFAULT 'SANO'::character varying,
    cara_distal character varying(15) DEFAULT 'SANO'::character varying,
    cara_oclusal character varying(15) DEFAULT 'SANO'::character varying,
    estado_general character varying(25) DEFAULT 'NORMAL'::character varying,
    en_puente_fijo boolean DEFAULT false NOT NULL,
    tiene_protesis_corona boolean DEFAULT false NOT NULL,
    CONSTRAINT piezas_dentales_cara_distal_check CHECK (((cara_distal)::text = ANY ((ARRAY['SANO'::character varying, 'CARIES'::character varying, 'RESINA'::character varying, 'AMALGAMA'::character varying])::text[]))),
    CONSTRAINT piezas_dentales_cara_lingual_check CHECK (((cara_lingual)::text = ANY ((ARRAY['SANO'::character varying, 'CARIES'::character varying, 'RESINA'::character varying, 'AMALGAMA'::character varying])::text[]))),
    CONSTRAINT piezas_dentales_cara_mesial_check CHECK (((cara_mesial)::text = ANY ((ARRAY['SANO'::character varying, 'CARIES'::character varying, 'RESINA'::character varying, 'AMALGAMA'::character varying])::text[]))),
    CONSTRAINT piezas_dentales_cara_oclusal_check CHECK (((cara_oclusal)::text = ANY ((ARRAY['SANO'::character varying, 'CARIES'::character varying, 'RESINA'::character varying, 'AMALGAMA'::character varying])::text[]))),
    CONSTRAINT piezas_dentales_cara_vestibular_check CHECK (((cara_vestibular)::text = ANY ((ARRAY['SANO'::character varying, 'CARIES'::character varying, 'RESINA'::character varying, 'AMALGAMA'::character varying])::text[]))),
    CONSTRAINT piezas_dentales_estado_general_check CHECK (((estado_general)::text = ANY ((ARRAY['NORMAL'::character varying, 'EXTRACCION'::character varying, 'AUSENTE'::character varying])::text[])))
);


ALTER TABLE public.piezas_dentales OWNER TO clinix_user;

--
-- Name: piezas_dentales_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.piezas_dentales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.piezas_dentales_id_seq OWNER TO clinix_user;

--
-- Name: piezas_dentales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.piezas_dentales_id_seq OWNED BY public.piezas_dentales.id;


--
-- Name: procedimientos_enfermeria; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.procedimientos_enfermeria (
    id integer NOT NULL,
    triaje_id integer NOT NULL,
    tipo_procedimiento character varying(50) NOT NULL,
    cantidad smallint DEFAULT 1 NOT NULL,
    observaciones character varying(200),
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT procedimientos_enfermeria_cantidad_check CHECK ((cantidad > 0))
);


ALTER TABLE public.procedimientos_enfermeria OWNER TO clinix_user;

--
-- Name: procedimientos_enfermeria_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.procedimientos_enfermeria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procedimientos_enfermeria_id_seq OWNER TO clinix_user;

--
-- Name: procedimientos_enfermeria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.procedimientos_enfermeria_id_seq OWNED BY public.procedimientos_enfermeria.id;


--
-- Name: reportes_estadisticos_mensuales; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.reportes_estadisticos_mensuales (
    id integer NOT NULL,
    unidad_medica_id integer NOT NULL,
    mes smallint NOT NULL,
    anio smallint NOT NULL,
    total_consultas integer NOT NULL,
    total_primeras_veces integer NOT NULL,
    total_subsecuentes integer NOT NULL,
    desglose_sexo jsonb NOT NULL,
    desglose_grupos_edad jsonb NOT NULL,
    desglose_morbilidad jsonb NOT NULL,
    cuadre_valido boolean DEFAULT true NOT NULL,
    fecha_generacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT reportes_estadisticos_mensuales_anio_check CHECK ((anio >= 2024)),
    CONSTRAINT reportes_estadisticos_mensuales_mes_check CHECK (((mes >= 1) AND (mes <= 12)))
);


ALTER TABLE public.reportes_estadisticos_mensuales OWNER TO clinix_user;

--
-- Name: reportes_estadisticos_mensuales_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.reportes_estadisticos_mensuales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reportes_estadisticos_mensuales_id_seq OWNER TO clinix_user;

--
-- Name: reportes_estadisticos_mensuales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.reportes_estadisticos_mensuales_id_seq OWNED BY public.reportes_estadisticos_mensuales.id;


--
-- Name: tratamientos_cruzados; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.tratamientos_cruzados (
    id integer NOT NULL,
    atencion_origen_id integer NOT NULL,
    area_origen character varying(30) NOT NULL,
    area_destino character varying(30) NOT NULL,
    prioridad character varying(15) DEFAULT 'NORMAL'::character varying NOT NULL,
    motivo_derivacion text NOT NULL,
    estado character varying(20) DEFAULT 'PENDIENTE'::character varying NOT NULL,
    fecha_hora_derivacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT tratamientos_cruzados_area_destino_check CHECK (((area_destino)::text = ANY ((ARRAY['MEDICINA_GENERAL'::character varying, 'ODONTOLOGIA'::character varying, 'NUTRICION'::character varying, 'PSICOLOGIA'::character varying])::text[]))),
    CONSTRAINT tratamientos_cruzados_estado_check CHECK (((estado)::text = ANY ((ARRAY['PENDIENTE'::character varying, 'ATENDIDO'::character varying, 'CANCELADO'::character varying])::text[]))),
    CONSTRAINT tratamientos_cruzados_prioridad_check CHECK (((prioridad)::text = ANY ((ARRAY['NORMAL'::character varying, 'URGENTE'::character varying])::text[])))
);


ALTER TABLE public.tratamientos_cruzados OWNER TO clinix_user;

--
-- Name: tratamientos_cruzados_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.tratamientos_cruzados_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tratamientos_cruzados_id_seq OWNER TO clinix_user;

--
-- Name: tratamientos_cruzados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.tratamientos_cruzados_id_seq OWNED BY public.tratamientos_cruzados.id;


--
-- Name: triaje_signos_vitales; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.triaje_signos_vitales (
    id integer NOT NULL,
    atencion_id integer NOT NULL,
    enfermero_id integer NOT NULL,
    tension_arterial character varying(15) NOT NULL,
    frecuencia_cardiaca smallint NOT NULL,
    frecuencia_respiratoria smallint NOT NULL,
    temperatura numeric(4,1) NOT NULL,
    saturacion_oxigeno smallint NOT NULL,
    glucosa_capilar smallint,
    peso_kg numeric(5,2) NOT NULL,
    talla_metros numeric(3,2) NOT NULL,
    imc numeric(4,1) NOT NULL,
    clasificacion_imc character varying(30) NOT NULL,
    detecciones_riesgo text,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT triaje_signos_vitales_frecuencia_cardiaca_check CHECK ((frecuencia_cardiaca > 0)),
    CONSTRAINT triaje_signos_vitales_frecuencia_respiratoria_check CHECK ((frecuencia_respiratoria > 0)),
    CONSTRAINT triaje_signos_vitales_glucosa_capilar_check CHECK ((glucosa_capilar > 0)),
    CONSTRAINT triaje_signos_vitales_peso_kg_check CHECK ((peso_kg > (0)::numeric)),
    CONSTRAINT triaje_signos_vitales_saturacion_oxigeno_check CHECK (((saturacion_oxigeno >= 0) AND (saturacion_oxigeno <= 100))),
    CONSTRAINT triaje_signos_vitales_talla_metros_check CHECK ((talla_metros > (0)::numeric)),
    CONSTRAINT triaje_signos_vitales_temperatura_check CHECK (((temperatura >= 30.0) AND (temperatura <= 45.0)))
);


ALTER TABLE public.triaje_signos_vitales OWNER TO clinix_user;

--
-- Name: triaje_signos_vitales_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.triaje_signos_vitales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.triaje_signos_vitales_id_seq OWNER TO clinix_user;

--
-- Name: triaje_signos_vitales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.triaje_signos_vitales_id_seq OWNED BY public.triaje_signos_vitales.id;


--
-- Name: tutores; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.tutores (
    id integer NOT NULL,
    paciente_id integer NOT NULL,
    nombre_completo character varying(150) NOT NULL,
    parentesco character varying(40) NOT NULL,
    telefono_contacto character varying(15) NOT NULL,
    tipo_identificacion character varying(50) NOT NULL,
    numero_identificacion character varying(50),
    CONSTRAINT tutores_parentesco_check CHECK (((parentesco)::text = ANY ((ARRAY['Madre'::character varying, 'Padre'::character varying, 'Tutor Legal'::character varying, 'Abuelo/a'::character varying, 'Otro'::character varying])::text[])))
);


ALTER TABLE public.tutores OWNER TO clinix_user;

--
-- Name: tutores_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.tutores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tutores_id_seq OWNER TO clinix_user;

--
-- Name: tutores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.tutores_id_seq OWNED BY public.tutores.id;


--
-- Name: unidades_medicas; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.unidades_medicas (
    id integer NOT NULL,
    nombre character varying(120) NOT NULL,
    clave_oficial character varying(20) NOT NULL,
    direccion character varying(250) NOT NULL,
    colonia character varying(100) NOT NULL,
    telefono character varying(15),
    georreferencia character varying(50),
    activo boolean DEFAULT true NOT NULL,
    consultorios integer DEFAULT 4,
    especialidades_activas jsonb DEFAULT '["Medicina General", "Odontología", "Nutrición", "Psicología", "Enfermería / Triaje"]'::jsonb,
    medicos_por_especialidad jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.unidades_medicas OWNER TO clinix_user;

--
-- Name: unidades_medicas_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.unidades_medicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.unidades_medicas_id_seq OWNER TO clinix_user;

--
-- Name: unidades_medicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.unidades_medicas_id_seq OWNED BY public.unidades_medicas.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: clinix_user
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    unidad_medica_id integer NOT NULL,
    nombre character varying(80) NOT NULL,
    apellidos character varying(100) NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(255),
    rol character varying(30) NOT NULL,
    cedula_profesional character varying(25),
    activo boolean DEFAULT true NOT NULL,
    ultimo_acceso timestamp without time zone,
    token_activacion character varying(255),
    token_expiracion timestamp without time zone,
    turno character varying(30),
    CONSTRAINT usuarios_rol_check CHECK (((rol)::text = ANY ((ARRAY['RECEPCION'::character varying, 'ENFERMERIA'::character varying, 'MEDICO_GENERAL'::character varying, 'ODONTOLOGO'::character varying, 'NUTRIOLOGO'::character varying, 'PSICOLOGO'::character varying, 'DIRECCION'::character varying])::text[])))
);


ALTER TABLE public.usuarios OWNER TO clinix_user;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: clinix_user
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_seq OWNER TO clinix_user;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: clinix_user
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: atenciones_clinicas id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.atenciones_clinicas ALTER COLUMN id SET DEFAULT nextval('public.atenciones_clinicas_id_seq'::regclass);


--
-- Name: bitacora_productividad_diaria id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.bitacora_productividad_diaria ALTER COLUMN id SET DEFAULT nextval('public.bitacora_productividad_diaria_id_seq'::regclass);


--
-- Name: consentimientos_informados id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consentimientos_informados ALTER COLUMN id SET DEFAULT nextval('public.consentimientos_informados_id_seq'::regclass);


--
-- Name: consultas_base id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_base ALTER COLUMN id SET DEFAULT nextval('public.consultas_base_id_seq'::regclass);


--
-- Name: consultas_medicina_general id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_medicina_general ALTER COLUMN id SET DEFAULT nextval('public.consultas_medicina_general_id_seq'::regclass);


--
-- Name: consultas_nutricion id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_nutricion ALTER COLUMN id SET DEFAULT nextval('public.consultas_nutricion_id_seq'::regclass);


--
-- Name: consultas_odontologia id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_odontologia ALTER COLUMN id SET DEFAULT nextval('public.consultas_odontologia_id_seq'::regclass);


--
-- Name: consultas_psicologia id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_psicologia ALTER COLUMN id SET DEFAULT nextval('public.consultas_psicologia_id_seq'::regclass);


--
-- Name: curvas_crecimiento_oms id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.curvas_crecimiento_oms ALTER COLUMN id SET DEFAULT nextval('public.curvas_crecimiento_oms_id_seq'::regclass);


--
-- Name: historias_clinicas id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.historias_clinicas ALTER COLUMN id SET DEFAULT nextval('public.historias_clinicas_id_seq'::regclass);


--
-- Name: pacientes id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.pacientes ALTER COLUMN id SET DEFAULT nextval('public.pacientes_id_seq'::regclass);


--
-- Name: piezas_dentales id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.piezas_dentales ALTER COLUMN id SET DEFAULT nextval('public.piezas_dentales_id_seq'::regclass);


--
-- Name: procedimientos_enfermeria id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.procedimientos_enfermeria ALTER COLUMN id SET DEFAULT nextval('public.procedimientos_enfermeria_id_seq'::regclass);


--
-- Name: reportes_estadisticos_mensuales id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.reportes_estadisticos_mensuales ALTER COLUMN id SET DEFAULT nextval('public.reportes_estadisticos_mensuales_id_seq'::regclass);


--
-- Name: tratamientos_cruzados id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tratamientos_cruzados ALTER COLUMN id SET DEFAULT nextval('public.tratamientos_cruzados_id_seq'::regclass);


--
-- Name: triaje_signos_vitales id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.triaje_signos_vitales ALTER COLUMN id SET DEFAULT nextval('public.triaje_signos_vitales_id_seq'::regclass);


--
-- Name: tutores id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tutores ALTER COLUMN id SET DEFAULT nextval('public.tutores_id_seq'::regclass);


--
-- Name: unidades_medicas id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.unidades_medicas ALTER COLUMN id SET DEFAULT nextval('public.unidades_medicas_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: atenciones_clinicas; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.atenciones_clinicas (id, paciente_id, unidad_medica_id, usuario_recepcion_id, fecha_hora_ingreso, tipo_atencion, estado, area_servicio) FROM stdin;
1	1	1	9	2026-10-29 20:08:15.709838	PRIMERA_VEZ	TRIAJE	Nutrición
\.


--
-- Data for Name: bitacora_productividad_diaria; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.bitacora_productividad_diaria (id, usuario_id, unidad_medica_id, fecha, total_atenciones, desglose_servicios) FROM stdin;
\.


--
-- Data for Name: consentimientos_informados; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consentimientos_informados (id, consulta_id, paciente_id, tutor_id, grupo_edad, texto_legal, firmado, fecha_firma) FROM stdin;
\.


--
-- Data for Name: consultas_base; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consultas_base (id, atencion_id, especialista_id, area_medica, fecha_hora, motivo_consulta, observaciones) FROM stdin;
\.


--
-- Data for Name: consultas_medicina_general; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consultas_medicina_general (id, consulta_id, nota_subjetivo, nota_objetivo, nota_analisis, nota_plan, diagnostico_cie10, diagnostico_descripcion, clasificacion_morbilidad, pruebas_rapidas, canalizacion_externa, emite_certificado) FROM stdin;
\.


--
-- Data for Name: consultas_nutricion; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consultas_nutricion (id, consulta_id, circunferencia_cintura, circunferencia_cadera, circunferencia_brazo, porcentaje_grasa, porcentaje_musculo, consumo_agua_litros, frecuencia_ejercicio, recordatorio_24h, antecedentes_patologicos) FROM stdin;
\.


--
-- Data for Name: consultas_odontologia; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consultas_odontologia (id, consulta_id, tipo_denticion, comorbilidades_bucales, estudios_gabinete, indice_cpod, indice_ceod) FROM stdin;
\.


--
-- Data for Name: consultas_psicologia; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.consultas_psicologia (id, consulta_id, evaluacion_clinica, nota_evolucion, plan_intervencion) FROM stdin;
\.


--
-- Data for Name: curvas_crecimiento_oms; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.curvas_crecimiento_oms (id, consulta_nutricion_id, rango_edad_oms, zscore_peso_edad, zscore_talla_edad, zscore_imc_edad, percentil_calculado) FROM stdin;
\.


--
-- Data for Name: historias_clinicas; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.historias_clinicas (id, paciente_id, usuario_registro_id, fecha_registro, fecha_actualizacion, ahf_diabetes, ahf_hipertension, ahf_cardiopatias, ahf_neoplasias, ahf_nefropatias, ahf_enfermedades_mentales, ahf_otros, app_alergias, app_quirurgicos, app_transfusionales, app_traumaticos, app_hospitalizaciones, app_cronico_degenerativas, app_otros, apnp_tabaquismo, apnp_tabaquismo_descripcion, apnp_alcoholismo, apnp_alcoholismo_descripcion, apnp_toxicomania, apnp_vacunacion_completa, apnp_vivienda_servicios, apnp_zoonosis, apnp_actividad_fisica, ago_menarca, ago_ritmo_menstrual, ago_fum, ago_gestas, ago_partos, ago_cesareas, ago_abortos, ago_metodo_anticonceptivo, ago_papanicolaou_fecha, ago_mastografia_fecha, ago_observaciones) FROM stdin;
\.


--
-- Data for Name: oms_referencia_imc; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.oms_referencia_imc (edad, sexo, sd_menos_3, sd_menos_2, sd_menos_1, mediana, sd_mas_1, sd_mas_2, sd_mas_3) FROM stdin;
5	F	11.80	12.70	13.90	15.30	16.90	18.90	21.50
6	F	11.90	12.80	14.00	15.50	17.30	19.60	22.60
7	F	12.00	12.90	14.20	15.80	17.80	20.30	23.70
8	F	12.10	13.10	14.40	16.20	18.30	21.00	24.80
9	F	12.30	13.30	14.80	16.70	19.00	22.10	26.50
10	F	12.50	13.60	15.20	17.20	19.80	23.20	28.20
11	F	12.80	14.00	15.70	17.90	20.70	24.50	30.00
12	F	13.20	14.50	16.30	18.70	21.70	25.80	31.80
13	F	13.60	15.00	16.90	19.40	22.60	26.80	33.00
14	F	14.00	15.50	17.50	20.10	23.40	27.70	34.00
15	F	14.40	16.00	18.10	20.80	24.20	28.60	35.00
16	F	14.50	16.20	18.30	21.00	24.50	28.90	35.40
17	F	14.60	16.30	18.50	21.20	24.70	29.20	35.80
18	F	14.70	16.40	18.60	21.30	24.90	29.50	36.10
19	F	14.80	16.50	18.70	21.40	25.00	29.70	36.30
5	M	12.10	13.00	14.10	15.30	16.60	18.30	20.50
6	M	12.20	13.10	14.20	15.50	17.00	19.00	21.60
7	M	12.30	13.20	14.30	15.70	17.40	19.70	22.80
8	M	12.40	13.30	14.50	16.00	17.90	20.50	24.00
9	M	12.60	13.50	14.80	16.40	18.40	21.30	25.40
10	M	12.80	13.80	15.10	16.80	19.00	22.20	26.80
11	M	13.10	14.10	15.50	17.40	19.90	23.40	28.50
12	M	13.40	14.50	16.00	18.00	20.80	24.60	30.20
13	M	13.70	14.90	16.60	18.70	21.60	25.60	31.70
14	M	14.00	15.40	17.20	19.40	22.40	26.60	33.20
15	M	14.40	15.90	17.80	20.20	23.30	27.70	34.80
16	M	14.80	16.40	18.30	20.80	23.90	28.30	35.20
17	M	15.20	16.80	18.80	21.30	24.50	28.90	35.60
18	M	15.70	17.30	19.30	21.90	25.10	29.50	36.00
19	M	15.90	17.50	19.50	22.20	25.40	29.80	36.30
\.


--
-- Data for Name: pacientes; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.pacientes (id, unidad_medica_id, numero_expediente, fecha_registro, nombres, apellido_paterno, apellido_materno, curp, fecha_nacimiento, sexo, estado_civil, escolaridad, calle_numero, colonia, codigo_postal, telefono, derechohabiencia, enfermedades_previas, beneficiario_programa, nombre_programa, num_personas_vivienda, numero_afiliacion, grupo_sanguineo, religion, ocupacion, tipo_poblacion, area_servicio) FROM stdin;
1	1	EXP-2026-95706	2026-10-29 20:08:15.709838	maria elena	rodriguez	vargas	ROVE000701MBCDRLAS	2000-07-01	F	Unión libre	Preparatoria	ca	aa	\N	1234124312	IMSS	\N	f	\N	1	\N	\N	\N	\N	\N	Nutrición
\.


--
-- Data for Name: piezas_dentales; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.piezas_dentales (id, consulta_odontologia_id, numero_fdi, cara_vestibular, cara_lingual, cara_mesial, cara_distal, cara_oclusal, estado_general, en_puente_fijo, tiene_protesis_corona) FROM stdin;
\.


--
-- Data for Name: procedimientos_enfermeria; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.procedimientos_enfermeria (id, triaje_id, tipo_procedimiento, cantidad, observaciones, fecha_hora) FROM stdin;
\.


--
-- Data for Name: reportes_estadisticos_mensuales; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.reportes_estadisticos_mensuales (id, unidad_medica_id, mes, anio, total_consultas, total_primeras_veces, total_subsecuentes, desglose_sexo, desglose_grupos_edad, desglose_morbilidad, cuadre_valido, fecha_generacion) FROM stdin;
1	1	9	2026	8	5	3	{"femenino": 0, "masculino": 8}	{"de_1_a_4": 0, "de_5_a_14": 2, "de_15_a_29": 0, "de_30_a_59": 6, "mayores_60": 0, "menores_1_ano": 0}	{"Consulta General / Valoración": 8, "Infecciones Respiratorias Agudas": 1, "Infecciones respiratorias agudas": 1}	t	2026-09-25 22:00:00.488892
\.


--
-- Data for Name: tratamientos_cruzados; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.tratamientos_cruzados (id, atencion_origen_id, area_origen, area_destino, prioridad, motivo_derivacion, estado, fecha_hora_derivacion) FROM stdin;
\.


--
-- Data for Name: triaje_signos_vitales; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.triaje_signos_vitales (id, atencion_id, enfermero_id, tension_arterial, frecuencia_cardiaca, frecuencia_respiratoria, temperatura, saturacion_oxigeno, glucosa_capilar, peso_kg, talla_metros, imc, clasificacion_imc, detecciones_riesgo, fecha_hora) FROM stdin;
\.


--
-- Data for Name: tutores; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.tutores (id, paciente_id, nombre_completo, parentesco, telefono_contacto, tipo_identificacion, numero_identificacion) FROM stdin;
\.


--
-- Data for Name: unidades_medicas; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.unidades_medicas (id, nombre, clave_oficial, direccion, colonia, telefono, georreferencia, activo, consultorios, especialidades_activas, medicos_por_especialidad) FROM stdin;
1	Clínica Central (Centro)	DSPM-COATZA-01	Av. Hilario Rodríguez Malpica 402, Centro	Centro	9212112100	\N	t	4	["Medicina General", "Odontología", "Nutrición", "Psicología", "Enfermería / Triaje"]	{}
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: clinix_user
--

COPY public.usuarios (id, unidad_medica_id, nombre, apellidos, email, password_hash, rol, cedula_profesional, activo, ultimo_acceso, token_activacion, token_expiracion, turno) FROM stdin;
13	1	L.N. Daniela	Peralta Silva	nutri@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	NUTRIOLOGO	NUT-505	t	2026-10-29 18:50:41.870354	\N	\N	\N
1	1	Administrador	Sistema Clinix	admin@clinix.coatzacoalcos.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.j2fmyYM.ycQtKnsxJIh0qVDqz/qyIOG	DIRECCION	ADMIN-001	f	2026-09-28 18:29:10.242266	\N	\N	\N
2	1	Ana Laura	Martínez Ramos	ana.martinez@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	MEDICO_GENERAL	CED-893412	f	2026-09-25 19:01:05.939	\N	\N	\N
11	1	Dr. Carlos	Gómez Herrera	medico@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	MEDICO_GENERAL	MED-303	t	2026-10-09 08:24:02.634145	\N	\N	\N
17	1	Carlos	Ablerto Carmona LLopez	carloscarmona4554@gmail.com	$2b$12$aoqnfwlc2AH8Pcr2Di.6WuhiZxzdx8VWVjXPq7YJpbjog3Q074EKq	MEDICO_GENERAL	12345679	t	\N	dd8c57b944c474531137adb089a19a152a264f37a361b4b98c54643024b7ac2e	2026-10-24 00:30:10.885	\N
10	1	Lic. Sofía	Mendoza Ramos	enfermeria@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	ENFERMERIA	ENF-202	t	2026-10-30 06:38:34.443781	\N	\N	\N
9	1	María Elena	Cruz Santos	recepcion@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	RECEPCION	REC-101	t	2026-10-30 06:49:14.97927	\N	\N	\N
50	1	juan	peres	gmqajuanitoabdul@gmail.com	$2b$12$/8kZMyvhHW483icegjYV1e4/QQ5RHZXcHzrr3qwhY8zdZ7exTd/PO	MEDICO_GENERAL	1234567890	t	\N	\N	\N	\N
12	1	Dra. Brenda	Castillo Lara	odonto@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	ODONTOLOGO	ODO-404	t	2026-10-09 09:46:26.793078	\N	\N	\N
14	1	Psic. Jorge	Morales Díaz	psico@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	PSICOLOGO	PSI-606	t	2026-10-09 10:57:49.680271	\N	\N	\N
8	1	Dr. Roberto	Alor Vázquez	admin@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	DIRECCION	DIR-001	t	2026-10-25 03:07:28.213686	\N	\N	\N
51	1	Antonio	Lopez	locosdelinternet2000@gmial.com	$2b$12$OBIlmeSW/w8PfiZtOIFXtuLfuD/W909ktdlKOsvoCH7kOlRod.sjK	MEDICO_GENERAL	12345667	t	\N	\N	\N	\N
4	1	Carlos	Vargas Luna	carlos.enfermeria@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	ENFERMERIA	ENF-445566	t	2026-09-25 18:53:06.969886	\N	\N	\N
5	1	Diego	Herrera Castillo	diego.nutricion@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	NUTRIOLOGO	NUT-778899	t	2026-09-25 19:07:52.155452	\N	\N	\N
3	1	Sofía	Gómez Hernández	sofia.recepcion@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	RECEPCION	\N	t	2026-09-25 19:15:10.648367	\N	\N	\N
6	1	Valeria	Morales Cruz	valeria.psicologia@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	PSICOLOGO	PSI-332211	t	2026-09-25 19:18:59.829939	\N	\N	\N
7	1	Dra. Patricia	Sánchez Enríquez	directora.salud@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	DIRECCION	DIR-100200	t	2026-09-25 19:29:47.085559	\N	\N	\N
15	1	Dr. Alejandro	Ramírez Solís	dr.nuevo.1790977783475@clinix.gob.mx	$2b$12$5CEXr1S6jAjsgscParfx3.pjGNs/aMlt9Zur3/YnG78h6OzQ9zZ3q	MEDICO_GENERAL	CED-MED-9944	f	\N	\N	\N	\N
16	1	Dr. Alejandro	Ramírez Solís	dr.nuevo.1791614495441@clinix.gob.mx	$2b$12$OR3axpvgnju39z.E2zTh6O/oV1xzI7JKQrb8PPQui4XEegDnE1noO	MEDICO_GENERAL	CED-MED-9944	f	\N	\N	\N	\N
\.


--
-- Name: atenciones_clinicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.atenciones_clinicas_id_seq', 1, true);


--
-- Name: bitacora_productividad_diaria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.bitacora_productividad_diaria_id_seq', 1, false);


--
-- Name: consentimientos_informados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consentimientos_informados_id_seq', 1, false);


--
-- Name: consultas_base_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consultas_base_id_seq', 1, false);


--
-- Name: consultas_medicina_general_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consultas_medicina_general_id_seq', 1, false);


--
-- Name: consultas_nutricion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consultas_nutricion_id_seq', 1, false);


--
-- Name: consultas_odontologia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consultas_odontologia_id_seq', 1, false);


--
-- Name: consultas_psicologia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.consultas_psicologia_id_seq', 1, false);


--
-- Name: curvas_crecimiento_oms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.curvas_crecimiento_oms_id_seq', 1, false);


--
-- Name: historias_clinicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.historias_clinicas_id_seq', 1, false);


--
-- Name: pacientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.pacientes_id_seq', 1, true);


--
-- Name: piezas_dentales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.piezas_dentales_id_seq', 1, false);


--
-- Name: procedimientos_enfermeria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.procedimientos_enfermeria_id_seq', 1, false);


--
-- Name: reportes_estadisticos_mensuales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.reportes_estadisticos_mensuales_id_seq', 2, true);


--
-- Name: tratamientos_cruzados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.tratamientos_cruzados_id_seq', 1, false);


--
-- Name: triaje_signos_vitales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.triaje_signos_vitales_id_seq', 1, false);


--
-- Name: tutores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.tutores_id_seq', 1, false);


--
-- Name: unidades_medicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.unidades_medicas_id_seq', 1, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clinix_user
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 51, true);


--
-- Name: atenciones_clinicas atenciones_clinicas_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.atenciones_clinicas
    ADD CONSTRAINT atenciones_clinicas_pkey PRIMARY KEY (id);


--
-- Name: bitacora_productividad_diaria bitacora_productividad_diaria_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.bitacora_productividad_diaria
    ADD CONSTRAINT bitacora_productividad_diaria_pkey PRIMARY KEY (id);


--
-- Name: consentimientos_informados consentimientos_informados_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consentimientos_informados
    ADD CONSTRAINT consentimientos_informados_pkey PRIMARY KEY (id);


--
-- Name: consultas_base consultas_base_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_base
    ADD CONSTRAINT consultas_base_pkey PRIMARY KEY (id);


--
-- Name: consultas_medicina_general consultas_medicina_general_consulta_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_medicina_general
    ADD CONSTRAINT consultas_medicina_general_consulta_id_key UNIQUE (consulta_id);


--
-- Name: consultas_medicina_general consultas_medicina_general_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_medicina_general
    ADD CONSTRAINT consultas_medicina_general_pkey PRIMARY KEY (id);


--
-- Name: consultas_nutricion consultas_nutricion_consulta_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_nutricion
    ADD CONSTRAINT consultas_nutricion_consulta_id_key UNIQUE (consulta_id);


--
-- Name: consultas_nutricion consultas_nutricion_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_nutricion
    ADD CONSTRAINT consultas_nutricion_pkey PRIMARY KEY (id);


--
-- Name: consultas_odontologia consultas_odontologia_consulta_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_odontologia
    ADD CONSTRAINT consultas_odontologia_consulta_id_key UNIQUE (consulta_id);


--
-- Name: consultas_odontologia consultas_odontologia_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_odontologia
    ADD CONSTRAINT consultas_odontologia_pkey PRIMARY KEY (id);


--
-- Name: consultas_psicologia consultas_psicologia_consulta_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_psicologia
    ADD CONSTRAINT consultas_psicologia_consulta_id_key UNIQUE (consulta_id);


--
-- Name: consultas_psicologia consultas_psicologia_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_psicologia
    ADD CONSTRAINT consultas_psicologia_pkey PRIMARY KEY (id);


--
-- Name: curvas_crecimiento_oms curvas_crecimiento_oms_consulta_nutricion_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.curvas_crecimiento_oms
    ADD CONSTRAINT curvas_crecimiento_oms_consulta_nutricion_id_key UNIQUE (consulta_nutricion_id);


--
-- Name: curvas_crecimiento_oms curvas_crecimiento_oms_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.curvas_crecimiento_oms
    ADD CONSTRAINT curvas_crecimiento_oms_pkey PRIMARY KEY (id);


--
-- Name: historias_clinicas historias_clinicas_paciente_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.historias_clinicas
    ADD CONSTRAINT historias_clinicas_paciente_id_key UNIQUE (paciente_id);


--
-- Name: historias_clinicas historias_clinicas_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.historias_clinicas
    ADD CONSTRAINT historias_clinicas_pkey PRIMARY KEY (id);


--
-- Name: oms_referencia_imc oms_referencia_imc_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.oms_referencia_imc
    ADD CONSTRAINT oms_referencia_imc_pkey PRIMARY KEY (edad, sexo);


--
-- Name: pacientes pacientes_curp_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_curp_key UNIQUE (curp);


--
-- Name: pacientes pacientes_numero_expediente_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_numero_expediente_key UNIQUE (numero_expediente);


--
-- Name: pacientes pacientes_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_pkey PRIMARY KEY (id);


--
-- Name: piezas_dentales piezas_dentales_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.piezas_dentales
    ADD CONSTRAINT piezas_dentales_pkey PRIMARY KEY (id);


--
-- Name: procedimientos_enfermeria procedimientos_enfermeria_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.procedimientos_enfermeria
    ADD CONSTRAINT procedimientos_enfermeria_pkey PRIMARY KEY (id);


--
-- Name: reportes_estadisticos_mensuales reportes_estadisticos_mensuales_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.reportes_estadisticos_mensuales
    ADD CONSTRAINT reportes_estadisticos_mensuales_pkey PRIMARY KEY (id);


--
-- Name: tratamientos_cruzados tratamientos_cruzados_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tratamientos_cruzados
    ADD CONSTRAINT tratamientos_cruzados_pkey PRIMARY KEY (id);


--
-- Name: triaje_signos_vitales triaje_signos_vitales_atencion_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.triaje_signos_vitales
    ADD CONSTRAINT triaje_signos_vitales_atencion_id_key UNIQUE (atencion_id);


--
-- Name: triaje_signos_vitales triaje_signos_vitales_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.triaje_signos_vitales
    ADD CONSTRAINT triaje_signos_vitales_pkey PRIMARY KEY (id);


--
-- Name: tutores tutores_paciente_id_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tutores
    ADD CONSTRAINT tutores_paciente_id_key UNIQUE (paciente_id);


--
-- Name: tutores tutores_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tutores
    ADD CONSTRAINT tutores_pkey PRIMARY KEY (id);


--
-- Name: unidades_medicas unidades_medicas_clave_oficial_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.unidades_medicas
    ADD CONSTRAINT unidades_medicas_clave_oficial_key UNIQUE (clave_oficial);


--
-- Name: unidades_medicas unidades_medicas_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.unidades_medicas
    ADD CONSTRAINT unidades_medicas_pkey PRIMARY KEY (id);


--
-- Name: bitacora_productividad_diaria uq_bitacora_usuario_fecha; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.bitacora_productividad_diaria
    ADD CONSTRAINT uq_bitacora_usuario_fecha UNIQUE (usuario_id, fecha);


--
-- Name: reportes_estadisticos_mensuales uq_reporte_unidad_periodo; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.reportes_estadisticos_mensuales
    ADD CONSTRAINT uq_reporte_unidad_periodo UNIQUE (unidad_medica_id, mes, anio);


--
-- Name: usuarios usuarios_email_key; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_email_key UNIQUE (email);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: idx_atenciones_area; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_atenciones_area ON public.atenciones_clinicas USING btree (area_servicio);


--
-- Name: idx_atenciones_estado; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_atenciones_estado ON public.atenciones_clinicas USING btree (estado);


--
-- Name: idx_atenciones_fecha; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_atenciones_fecha ON public.atenciones_clinicas USING btree (fecha_hora_ingreso);


--
-- Name: idx_atenciones_paciente_fecha; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_atenciones_paciente_fecha ON public.atenciones_clinicas USING btree (paciente_id, fecha_hora_ingreso DESC);


--
-- Name: idx_bitacora_fecha; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_bitacora_fecha ON public.bitacora_productividad_diaria USING btree (fecha);


--
-- Name: idx_consultas_base_area; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_consultas_base_area ON public.consultas_base USING btree (area_medica);


--
-- Name: idx_consultas_base_atencion; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_consultas_base_atencion ON public.consultas_base USING btree (atencion_id);


--
-- Name: idx_consultas_medicina; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_consultas_medicina ON public.consultas_medicina_general USING btree (consulta_id);


--
-- Name: idx_consultas_nutricion; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_consultas_nutricion ON public.consultas_nutricion USING btree (consulta_id);


--
-- Name: idx_consultas_odontologia; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_consultas_odontologia ON public.consultas_odontologia USING btree (consulta_id);


--
-- Name: idx_consultas_psicologia; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_consultas_psicologia ON public.consultas_psicologia USING btree (consulta_id);


--
-- Name: idx_historias_clinicas_paciente; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_historias_clinicas_paciente ON public.historias_clinicas USING btree (paciente_id);


--
-- Name: idx_pacientes_curp; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_pacientes_curp ON public.pacientes USING btree (curp);


--
-- Name: idx_pacientes_expediente; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_pacientes_expediente ON public.pacientes USING btree (numero_expediente);


--
-- Name: idx_pacientes_nombre; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_pacientes_nombre ON public.pacientes USING btree (apellido_paterno, apellido_materno, nombres);


--
-- Name: idx_piezas_dentales_consulta; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_piezas_dentales_consulta ON public.piezas_dentales USING btree (consulta_odontologia_id);


--
-- Name: idx_procedimientos_triaje; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_procedimientos_triaje ON public.procedimientos_enfermeria USING btree (triaje_id);


--
-- Name: idx_reportes_periodo; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_reportes_periodo ON public.reportes_estadisticos_mensuales USING btree (anio, mes);


--
-- Name: idx_triaje_atencion; Type: INDEX; Schema: public; Owner: clinix_user
--

CREATE INDEX idx_triaje_atencion ON public.triaje_signos_vitales USING btree (atencion_id);


--
-- Name: atenciones_clinicas atenciones_clinicas_paciente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.atenciones_clinicas
    ADD CONSTRAINT atenciones_clinicas_paciente_id_fkey FOREIGN KEY (paciente_id) REFERENCES public.pacientes(id) ON DELETE RESTRICT;


--
-- Name: atenciones_clinicas atenciones_clinicas_unidad_medica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.atenciones_clinicas
    ADD CONSTRAINT atenciones_clinicas_unidad_medica_id_fkey FOREIGN KEY (unidad_medica_id) REFERENCES public.unidades_medicas(id) ON DELETE RESTRICT;


--
-- Name: atenciones_clinicas atenciones_clinicas_usuario_recepcion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.atenciones_clinicas
    ADD CONSTRAINT atenciones_clinicas_usuario_recepcion_id_fkey FOREIGN KEY (usuario_recepcion_id) REFERENCES public.usuarios(id) ON DELETE RESTRICT;


--
-- Name: bitacora_productividad_diaria bitacora_productividad_diaria_unidad_medica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.bitacora_productividad_diaria
    ADD CONSTRAINT bitacora_productividad_diaria_unidad_medica_id_fkey FOREIGN KEY (unidad_medica_id) REFERENCES public.unidades_medicas(id) ON DELETE RESTRICT;


--
-- Name: bitacora_productividad_diaria bitacora_productividad_diaria_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.bitacora_productividad_diaria
    ADD CONSTRAINT bitacora_productividad_diaria_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON DELETE RESTRICT;


--
-- Name: consentimientos_informados consentimientos_informados_consulta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consentimientos_informados
    ADD CONSTRAINT consentimientos_informados_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas_base(id) ON DELETE CASCADE;


--
-- Name: consentimientos_informados consentimientos_informados_paciente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consentimientos_informados
    ADD CONSTRAINT consentimientos_informados_paciente_id_fkey FOREIGN KEY (paciente_id) REFERENCES public.pacientes(id) ON DELETE RESTRICT;


--
-- Name: consentimientos_informados consentimientos_informados_tutor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consentimientos_informados
    ADD CONSTRAINT consentimientos_informados_tutor_id_fkey FOREIGN KEY (tutor_id) REFERENCES public.tutores(id) ON DELETE RESTRICT;


--
-- Name: consultas_base consultas_base_atencion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_base
    ADD CONSTRAINT consultas_base_atencion_id_fkey FOREIGN KEY (atencion_id) REFERENCES public.atenciones_clinicas(id) ON DELETE RESTRICT;


--
-- Name: consultas_base consultas_base_especialista_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_base
    ADD CONSTRAINT consultas_base_especialista_id_fkey FOREIGN KEY (especialista_id) REFERENCES public.usuarios(id) ON DELETE RESTRICT;


--
-- Name: consultas_medicina_general consultas_medicina_general_consulta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_medicina_general
    ADD CONSTRAINT consultas_medicina_general_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas_base(id) ON DELETE CASCADE;


--
-- Name: consultas_nutricion consultas_nutricion_consulta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_nutricion
    ADD CONSTRAINT consultas_nutricion_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas_base(id) ON DELETE CASCADE;


--
-- Name: consultas_odontologia consultas_odontologia_consulta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_odontologia
    ADD CONSTRAINT consultas_odontologia_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas_base(id) ON DELETE CASCADE;


--
-- Name: consultas_psicologia consultas_psicologia_consulta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.consultas_psicologia
    ADD CONSTRAINT consultas_psicologia_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas_base(id) ON DELETE CASCADE;


--
-- Name: curvas_crecimiento_oms curvas_crecimiento_oms_consulta_nutricion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.curvas_crecimiento_oms
    ADD CONSTRAINT curvas_crecimiento_oms_consulta_nutricion_id_fkey FOREIGN KEY (consulta_nutricion_id) REFERENCES public.consultas_nutricion(id) ON DELETE CASCADE;


--
-- Name: historias_clinicas historias_clinicas_paciente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.historias_clinicas
    ADD CONSTRAINT historias_clinicas_paciente_id_fkey FOREIGN KEY (paciente_id) REFERENCES public.pacientes(id) ON DELETE CASCADE;


--
-- Name: historias_clinicas historias_clinicas_usuario_registro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.historias_clinicas
    ADD CONSTRAINT historias_clinicas_usuario_registro_id_fkey FOREIGN KEY (usuario_registro_id) REFERENCES public.usuarios(id) ON DELETE SET NULL;


--
-- Name: pacientes pacientes_unidad_medica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_unidad_medica_id_fkey FOREIGN KEY (unidad_medica_id) REFERENCES public.unidades_medicas(id) ON DELETE RESTRICT;


--
-- Name: piezas_dentales piezas_dentales_consulta_odontologia_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.piezas_dentales
    ADD CONSTRAINT piezas_dentales_consulta_odontologia_id_fkey FOREIGN KEY (consulta_odontologia_id) REFERENCES public.consultas_odontologia(id) ON DELETE CASCADE;


--
-- Name: procedimientos_enfermeria procedimientos_enfermeria_triaje_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.procedimientos_enfermeria
    ADD CONSTRAINT procedimientos_enfermeria_triaje_id_fkey FOREIGN KEY (triaje_id) REFERENCES public.triaje_signos_vitales(id) ON DELETE CASCADE;


--
-- Name: reportes_estadisticos_mensuales reportes_estadisticos_mensuales_unidad_medica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.reportes_estadisticos_mensuales
    ADD CONSTRAINT reportes_estadisticos_mensuales_unidad_medica_id_fkey FOREIGN KEY (unidad_medica_id) REFERENCES public.unidades_medicas(id) ON DELETE RESTRICT;


--
-- Name: tratamientos_cruzados tratamientos_cruzados_atencion_origen_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tratamientos_cruzados
    ADD CONSTRAINT tratamientos_cruzados_atencion_origen_id_fkey FOREIGN KEY (atencion_origen_id) REFERENCES public.atenciones_clinicas(id) ON DELETE RESTRICT;


--
-- Name: triaje_signos_vitales triaje_signos_vitales_atencion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.triaje_signos_vitales
    ADD CONSTRAINT triaje_signos_vitales_atencion_id_fkey FOREIGN KEY (atencion_id) REFERENCES public.atenciones_clinicas(id) ON DELETE CASCADE;


--
-- Name: triaje_signos_vitales triaje_signos_vitales_enfermero_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.triaje_signos_vitales
    ADD CONSTRAINT triaje_signos_vitales_enfermero_id_fkey FOREIGN KEY (enfermero_id) REFERENCES public.usuarios(id) ON DELETE RESTRICT;


--
-- Name: tutores tutores_paciente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.tutores
    ADD CONSTRAINT tutores_paciente_id_fkey FOREIGN KEY (paciente_id) REFERENCES public.pacientes(id) ON DELETE CASCADE;


--
-- Name: usuarios usuarios_unidad_medica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinix_user
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_unidad_medica_id_fkey FOREIGN KEY (unidad_medica_id) REFERENCES public.unidades_medicas(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict e0nRhGNGNwr8CjsRhrjkuwXj68qGcjPDe6ycfN3fY7YPSAaBfjZ64mvwnjOiOhc

